/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'agent' | 'customer';
  avatar?: string;
}

export interface AIAnalysis {
  summary: string;
  sentiment: 'Positive' | 'Neutral' | 'Negative' | 'Frustrated' | 'Angry';
  suggestedSolution: string;
  predictedPriority: 'low' | 'medium' | 'high' | 'urgent';
  suggestedDepartment: string;
  confidenceScore: number;
  tags: string[];
  faqMatches: string[];
  status: 'pending' | 'accepted' | 'rejected' | 'edited';
  editedReply?: string;
}

export interface Ticket {
  id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  category: 'Billing' | 'Technical' | 'Account' | 'Feature Request' | 'General';
  department: string;
  status: 'open' | 'assigned' | 'resolved' | 'closed';
  customerId: string;
  customerName: string;
  customerEmail: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  screenshot?: string; // Base64 data or url
  createdAt: string;
  updatedAt: string;
  tags: string[];
  aiAnalysis?: AIAnalysis;
  feedback?: {
    rating: number;
    comment: string;
    createdAt: string;
  };
}

export interface Comment {
  id: string;
  ticketId: string;
  senderId: string;
  senderName: string;
  senderRole: 'admin' | 'agent' | 'customer' | 'ai';
  message: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  ticketId?: string;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  ticketId: string;
  actorName: string;
  action: string;
  createdAt: string;
}
