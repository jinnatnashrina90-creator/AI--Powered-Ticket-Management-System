/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import LandingPage from "./components/LandingPage";
import CustomerDashboard from "./components/CustomerDashboard";
import AdminDashboard from "./components/AdminDashboard";
import LaravelCenter from "./components/LaravelCenter";
import { Sparkles, Code, User, ShieldAlert, Home, ArrowRightLeft } from "lucide-react";

export default function App() {
  const [view, setView] = useState<'landing' | 'customer' | 'admin' | 'laravel'>('landing');
  
  // Current logged in user simulation
  const [currentUser, setCurrentUser] = useState<any>({
    id: "u-3",
    name: "Alex Mercer",
    email: "customer@example.com",
    role: "customer",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=120"
  });

  const handleStartDemo = (role: 'customer' | 'admin' | 'agent') => {
    if (role === 'admin') {
      setCurrentUser({
        id: "u-1",
        name: "Sarah Connor",
        email: "admin@supportflow.ai",
        role: "admin",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120"
      });
      setView('admin');
    } else {
      setCurrentUser({
        id: "u-3",
        name: "Alex Mercer",
        email: "customer@example.com",
        role: "customer",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=120"
      });
      setView('customer');
    }
  };

  const handleLogout = () => {
    setView('landing');
  };

  return (
    <div className="relative min-h-screen">
      {/* Dynamic View Renderer */}
      <div className="pb-16 sm:pb-0">
        {view === 'landing' && <LandingPage onStartDemo={handleStartDemo} />}
        {view === 'customer' && <CustomerDashboard user={currentUser} onLogout={handleLogout} />}
        {view === 'admin' && <AdminDashboard user={currentUser} onLogout={handleLogout} onGoToLaravel={() => setView('laravel')} />}
        {view === 'laravel' && (
          <div className="min-h-screen bg-slate-50 p-6 flex flex-col justify-between">
            <div className="max-w-7xl mx-auto w-full space-y-6">
              <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-rose-50 rounded-lg">
                    <Code className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <h1 className="text-xl font-display font-bold text-slate-900">Laravel 12 SupportFlow AI Stack</h1>
                    <p className="text-slate-500 text-xs mt-0.5">Explore the identical, interview-ready backend files for this SaaS solution.</p>
                  </div>
                </div>
                <button
                  onClick={() => setView('landing')}
                  className="text-xs font-semibold bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1 shadow-sm"
                >
                  <Home className="w-4 h-4 text-slate-500" />
                  <span>Return to Home</span>
                </button>
              </div>

              <LaravelCenter />
            </div>

            <footer className="text-center text-xs text-slate-400 mt-12 py-6 border-t border-slate-200 max-w-7xl mx-auto w-full">
              SupportFlow AI • Created for full stack PHP & AI Engineering assessments • 2026
            </footer>
          </div>
        )}
      </div>

      {/* Floating Evaluator Hub dock - Perfect for presentation/interviewers to jump states instantly */}
      <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 hover:bg-slate-950 backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-xl border border-slate-800/80 flex items-center gap-3 text-white max-w-[95%] sm:max-w-xl">
        <div className="flex items-center gap-1.5 shrink-0 text-amber-400 font-bold font-mono text-[10px] uppercase tracking-wider bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full">
          <Sparkles className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Presenter</span> Dock
        </div>
        
        <div className="h-4 w-px bg-slate-800 shrink-0"></div>

        <div className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => setView('landing')}
            className={`text-[10px] sm:text-xs font-semibold px-2.5 py-1.5 rounded-xl transition-all cursor-pointer ${
              view === 'landing' ? "bg-indigo-600 text-white font-bold" : "text-slate-400 hover:text-white"
            }`}
          >
            SaaS Home
          </button>
          <button
            onClick={() => handleStartDemo('customer')}
            className={`text-[10px] sm:text-xs font-semibold px-2.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
              view === 'customer' ? "bg-indigo-600 text-white font-bold" : "text-slate-400 hover:text-white"
            }`}
          >
            <User className="w-3 h-3 text-slate-400" />
            <span>Customer</span>
          </button>
          <button
            onClick={() => handleStartDemo('admin')}
            className={`text-[10px] sm:text-xs font-semibold px-2.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
              view === 'admin' ? "bg-indigo-600 text-white font-bold" : "text-slate-400 hover:text-white"
            }`}
          >
            <ShieldAlert className="w-3 h-3 text-slate-400" />
            <span>Admin</span>
          </button>
          <button
            onClick={() => setView('laravel')}
            className={`text-[10px] sm:text-xs font-semibold px-2.5 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1 ${
              view === 'laravel' ? "bg-red-600 text-white font-bold" : "text-slate-400 hover:text-white"
            }`}
          >
            <Code className="w-3 h-3 text-slate-400" />
            <span>Laravel Code</span>
          </button>
        </div>
      </div>
    </div>
  );
}
