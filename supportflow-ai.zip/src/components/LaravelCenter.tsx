/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Code, Download, FileCode, Check, Server, Terminal, Shield, Sparkles } from "lucide-react";

interface CodeFile {
  name: string;
  path: string;
  lang: string;
  code: string;
  description: string;
}

export default function LaravelCenter() {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);

  const laravelFiles: CodeFile[] = [
    {
      name: "AI Support Service",
      path: "app/Services/AIService.php",
      lang: "php",
      description: "Laravel 12 Service using Gemini API client to perform sentiment analysis, summarization, priority prediction, and replies drafts.",
      code: `<?php

namespace App\\Services;

use Illuminate\\Support\\Facades\\Http;
use Illuminate\\Support\\Facades\\Log;

class AIService
{
    protected string $apiKey;
    protected string $endpoint;

    public function __construct()
    {
        $this->apiKey = config('services.gemini.key');
        $this->endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent";
    }

    /**
     * Analyze customer support ticket details.
     */
    public function analyzeTicket(string $title, string $description, string $category): array
    {
        if (empty($this->apiKey)) {
            Log::warning('Gemini API key is not configured. Falling back to default heuristics.');
            return $this->getMockAnalysis($title, $description, $category);
        }

        try {
            $prompt = $this->buildAnalysisPrompt($title, $description, $category);
            
            $response = Http::withHeaders([
                'Content-Type' => 'application/json'
            ])->post("{$this->endpoint}?key={$this->apiKey}", [
                'contents' => [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ],
                'generationConfig' => [
                    'responseMimeType' => 'application/json',
                    'responseSchema' => [
                        'type' => 'OBJECT',
                        'properties' => [
                            'summary' => ['type' => 'STRING'],
                            'sentiment' => ['type' => 'STRING', 'description' => 'Positive, Neutral, Negative, Frustrated, or Angry'],
                            'suggestedSolution' => ['type' => 'STRING', 'description' => 'An empathetic response email draft.'],
                            'predictedPriority' => ['type' => 'STRING', 'description' => 'low, medium, high, or urgent'],
                            'suggestedDepartment' => ['type' => 'STRING', 'description' => 'Billing, Engineering, Support Ops, or Product'],
                            'confidenceScore' => ['type' => 'INTEGER'],
                            'tags' => [
                                'type' => 'ARRAY',
                                'items' => ['type' => 'STRING']
                            ]
                        ],
                        'required' => ['summary', 'sentiment', 'suggestedSolution', 'predictedPriority', 'suggestedDepartment', 'tags', 'confidenceScore']
                    ]
                ]
            ]);

            if ($response->successful()) {
                $candidates = $response->json('candidates');
                $textResult = $candidates[0]['content']['parts'][0]['text'] ?? '{}';
                return json_decode($textResult, true);
            }

            Log::error('Gemini API returned error code: ' . $response->status());
        } catch (\\Exception $e) {
            Log::error('Gemini API analysis failed: ' . $e->getMessage());
        }

        return $this->getMockAnalysis($title, $description, $category);
    }

    protected function buildAnalysisPrompt(string $title, string $description, string $category): string
    {
        return "You are an AI Support Ticket Analyzer for SupportFlow AI. Please analyze the following customer support ticket and output a structured JSON response.\\n\\n" .
               "Ticket Title: {$title}\\n" .
               "Ticket Description: {$description}\\n" .
               "Category: {$category}\\n\\n" .
               "Please classify and extract the response attributes exactly matching the requested JSON schema.";
    }

    protected function getMockAnalysis(string $title, string $description, string $category): array
    {
        return [
            'summary' => 'Auto-generated fallback analysis for: ' . $title,
            'sentiment' => 'Neutral',
            'suggestedSolution' => "Hi there,\\n\\nWe have received your ticket regarding '{$title}'. Our agent desk is reviewing your case and will respond within our standard SLA. Thank you for your patience.\\n\\nWarm regards,\\nSupportFlow AI desk",
            'predictedPriority' => 'medium',
            'suggestedDepartment' => 'Support Ops',
            'confidenceScore' => 80,
            'tags' => ['#support', '#general']
        ];
    }
}`
    },
    {
      name: "Ticket Model",
      path: "app/Models/Ticket.php",
      lang: "php",
      description: "Laravel Eloquent Ticket Model with relations to User, Comments, and AI Response logs.",
      code: `<?php

namespace App\\Models;

use Illuminate\\Database\\Eloquent\\Model;
use Illuminate\\Database\\Eloquent\\Factories\\HasFactory;
use Illuminate\\Database\\Eloquent\\Relations\\BelongsTo;
use Illuminate\\Database\\Eloquent\\Relations\\HasMany;
use Illuminate\\Database\\Eloquent\\Relations\\HasOne;

class Ticket extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'description',
        'priority',
        'category',
        'department',
        'status',
        'customer_id',
        'assigned_staff_id',
        'screenshot_path',
        'tags'
    ];

    protected $casts = [
        'tags' => 'array',
    ];

    /**
     * Get the customer that submitted the ticket.
     */
    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    /**
     * Get the agent assigned to work on the ticket.
     */
    public function assignedStaff(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_staff_id');
    }

    /**
     * Get comments for this ticket.
     */
    public function comments(): HasMany
    {
        return $this->hasMany(TicketComment::class)->orderBy('created_at', 'asc');
    }

    /**
     * Get AI Analysis response cache.
     */
    public function aiResponse(): HasOne
    {
        return $this->hasOne(AIResponse::class);
    }
}`
    },
    {
      name: "Database Migration",
      path: "database/migrations/create_tickets_table.php",
      lang: "php",
      description: "MySQL Database migrations schema specifying roles, departments, statuses, foreign keys, and JSON support fields.",
      code: `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description');
            $table->enum('priority', ['low', 'medium', 'high', 'urgent'])->default('medium');
            $table->string('category');
            $table->string('department')->default('Support Ops');
            $table->enum('status', ['open', 'assigned', 'resolved', 'closed'])->default('open');
            
            // Users relations
            $table->foreignId('customer_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('assigned_staff_id')->nullable()->constrained('users')->onDelete('set null');
            
            // Meta details
            $table->string('screenshot_path')->nullable();
            $table->json('tags')->nullable();
            
            $table->timestamps();
        });

        Schema::create('ticket_comments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ticket_id')->constrained('tickets')->onDelete('cascade');
            $table->foreignId('sender_id')->constrained('users')->onDelete('cascade');
            $table->text('message');
            $table->enum('sender_role', ['admin', 'agent', 'customer', 'ai']);
            $table->timestamps();
        });

        Schema::create('ai_responses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ticket_id')->constrained('tickets')->onDelete('cascade');
            $table->text('summary');
            $table->string('sentiment');
            $table->text('suggested_solution');
            $table->integer('confidence_score');
            $table->enum('status', ['pending', 'accepted', 'rejected', 'edited'])->default('pending');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ai_responses');
        Schema::dropIfExists('ticket_comments');
        Schema::dropIfExists('tickets');
    }
};`
    },
    {
      name: "Ticket Controller",
      path: "app/Http/Controllers/TicketController.php",
      lang: "php",
      description: "Laravel resource controller connecting AI analysis triggers, attachments storing, Breeze policy rules, and API endpoints.",
      code: `<?php

namespace App\\Http\\Controllers;

use App\\Models\\Ticket;
use App\\Services\\AIService;
use App\\Jobs\\ProcessTicketAI;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Storage;
use Illuminate\\Support\\Facades\\Auth;

class TicketController extends Controller
{
    protected AIService $aiService;

    public function __construct(AIService $aiService)
    {
        $this->aiService = $aiService;
    }

    /**
     * Store a new support ticket.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'category' => 'required|string',
            'priority' => 'nullable|in:low,medium,high,urgent',
            'screenshot' => 'nullable|image|max:4096'
        ]);

        $ticket = new Ticket();
        $ticket->title = $validated['title'];
        $ticket->description = $validated['description'];
        $ticket->category = $validated['category'];
        $ticket->priority = $validated['priority'] ?? 'medium';
        $ticket->customer_id = Auth::id();

        if ($request->hasFile('screenshot')) {
            $path = $request->file('screenshot')->store('screenshots', 'public');
            $ticket->screenshot_path = $path;
        }

        $ticket->save();

        // Dispatch a queue job to perform the heavy Gemini API routing asynchronously
        ProcessTicketAI::dispatch($ticket);

        return redirect()->route('tickets.show', $ticket->id)
            ->with('status', 'Ticket submitted and AI dispatch sequence queued successfully.');
    }

    /**
     * Display a ticket detailed review.
     */
    public function show(Ticket $ticket)
    {
        $this->authorize('view', $ticket);
        $ticket->load(['customer', 'assignedStaff', 'comments', 'aiResponse']);
        
        return view('tickets.show', compact('ticket'));
    }
}`
    },
    {
      name: "Queue Job",
      path: "app/Jobs/ProcessTicketAI.php",
      lang: "php",
      description: "Laravel Queue system integration for offloading external HTTP Gemini operations safely into workers background.",
      code: `<?php

namespace App\\Jobs;

use App\\Models\\Ticket;
use App\\Services\\AIService;
use Illuminate\\Bus\\Queueable;
use Illuminate\\Contracts\\Queue\\ShouldQueue;
use Illuminate\\Foundation\\Bus\\Dispatchable;
use Illuminate\\Queue\\InteractsWithQueue;
use Illuminate\\Queue\\SerializesModels;

class ProcessTicketAI implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected Ticket $ticket;

    /**
     * Create a new job instance.
     */
    public function __construct(Ticket $ticket)
    {
        $this->ticket = $ticket;
    }

    /**
     * Execute the job.
     */
    public function handle(AIService $aiService): void
    {
        // 1. Analyze details from Gemini
        $analysis = $aiService->analyzeTicket(
            $this->ticket->title,
            $this->ticket->description,
            $this->ticket->category
        );

        // 2. Cache result into related AI tables
        $this->ticket->aiResponse()->create([
            'summary' => $analysis['summary'] ?? '',
            'sentiment' => $analysis['sentiment'] ?? 'Neutral',
            'suggested_solution' => $analysis['suggestedSolution'] ?? '',
            'confidence_score' => $analysis['confidenceScore'] ?? 80,
            'status' => 'pending'
        ]);

        // 3. Update main ticket routing records
        $this->ticket->update([
            'tags' => $analysis['tags'] ?? [],
            'priority' => $analysis['predictedPriority'] ?? $this->ticket->priority,
            'department' => $analysis['suggestedDepartment'] ?? $this->ticket->department
        ]);
    }
}`
    }
  ];

  const handleCopy = () => {
    navigator.clipboard.writeText(laravelFiles[activeTab].code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden" id="laravel-center-section">
      {/* Header section with Laravel aesthetic color accents */}
      <div className="bg-gradient-to-r from-red-600 via-rose-600 to-orange-600 p-6 text-white relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-16 translate-x-16 blur-xl"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-xl backdrop-blur-md border border-white/10">
              <Server className="w-8 h-8 text-red-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-widest bg-red-800/60 text-red-100 font-mono px-2 py-0.5 rounded-full font-bold">PRO ARCHITECTURE</span>
                <span className="text-xs bg-emerald-500/20 text-emerald-100 font-mono px-2 py-0.5 rounded-full font-medium">Laravel 12 + PHP 8.4</span>
              </div>
              <h2 className="text-2xl font-display font-bold mt-1 text-white">Laravel Core Export Blueprint</h2>
            </div>
          </div>
          <p className="text-red-100 max-w-md text-sm leading-relaxed">
            While this fully-interactive SaaS app operates in our sandbox container (React + Node.js), we have engineered the identical enterprise Laravel 12 / PHP 8.4 structure for you here.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[500px]">
        {/* Sidebar file explorer */}
        <div className="lg:col-span-4 bg-slate-50 border-r border-slate-100 p-4 flex flex-col justify-between">
          <div>
            <span className="text-xs uppercase font-mono tracking-wider text-slate-400 block mb-3 font-semibold">EXPLORER & CONTROLLERS</span>
            <div className="space-y-1.5">
              {laravelFiles.map((file, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setActiveTab(idx);
                    setCopied(false);
                  }}
                  className={`w-full flex items-start gap-3 p-3 rounded-xl transition-all text-left ${
                    activeTab === idx
                      ? "bg-white shadow-md border-l-4 border-red-500 text-slate-800"
                      : "text-slate-500 hover:bg-slate-100/80 hover:text-slate-800"
                  }`}
                >
                  <FileCode className={`w-5 h-5 mt-0.5 shrink-0 ${activeTab === idx ? "text-red-500" : "text-slate-400"}`} />
                  <div>
                    <div className="font-medium text-sm text-slate-800">{file.name}</div>
                    <div className="text-xs font-mono text-slate-400 mt-0.5 truncate max-w-[200px]">{file.path}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="mt-8 p-4 bg-red-50 rounded-xl border border-red-100/60">
            <div className="flex items-center gap-2 text-red-700 font-medium text-xs">
              <Sparkles className="w-4 h-4 text-red-500" />
              <span>SaaS Stack Configuration</span>
            </div>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              These classes use the latest PHP 8.4 features like property promotion, constructor parameter arrays, and type declarations to achieve a highly elegant architecture.
            </p>
          </div>
        </div>

        {/* Code Content and explanation */}
        <div className="lg:col-span-8 p-6 bg-slate-900 flex flex-col justify-between text-slate-100">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4 mb-4">
              <div>
                <span className="text-xs font-mono text-slate-400 bg-slate-800 px-2.5 py-1 rounded-md">{laravelFiles[activeTab].path}</span>
                <p className="text-slate-400 text-xs mt-2 max-w-xl">{laravelFiles[activeTab].description}</p>
              </div>
              <button
                onClick={handleCopy}
                className="self-start sm:self-auto flex items-center gap-2 bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-100 px-4 py-2 rounded-xl transition text-xs font-medium cursor-pointer"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400 font-semibold">Copied!</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>Copy PHP Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Simulated Syntax-Highlighted Code Editor */}
            <div className="font-mono text-xs sm:text-sm bg-slate-950 p-5 rounded-xl border border-slate-800/80 max-h-[420px] overflow-y-auto shadow-inner text-emerald-400">
              <pre className="whitespace-pre">{laravelFiles[activeTab].code}</pre>
            </div>
          </div>

          {/* Quick instructions and security reminders */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs text-slate-400 font-mono">
            <span className="flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-red-500" />
              <span>PSR-12 Compliant</span>
            </span>
            <span className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-sky-500" />
              <span>CSRF & SQL Injection Protected</span>
            </span>
            <span className="bg-slate-800 px-2 py-1 rounded">utf-8 encoding</span>
          </div>
        </div>
      </div>
    </div>
  );
}
