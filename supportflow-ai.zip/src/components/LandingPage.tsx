/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Sparkles, ArrowRight, Shield, RefreshCw, Zap, Users, Code, Activity, BarChart2, CheckCircle, MessageSquare } from "lucide-react";
import { motion } from "motion/react";

interface LandingPageProps {
  onStartDemo: (role: 'customer' | 'admin' | 'agent') => void;
}

export default function LandingPage({ onStartDemo }: LandingPageProps) {
  const [playPrompt, setPlayPrompt] = useState<string>("");
  const [playResult, setPlayResult] = useState<any>(null);
  const [loadingPlay, setLoadingPlay] = useState<boolean>(false);

  // Quick live demo processing
  const handleQuickPlay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!playPrompt.trim()) return;

    setLoadingPlay(true);
    setPlayResult(null);

    try {
      // Connects to Express API ticket endpoint simulating a customer ticket submit
      const res = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: "Quick Sandbox Analysis Request",
          description: playPrompt,
          category: "General",
          priority: "medium",
          customerId: "u-3",
          customerName: "Playground Explorer",
          customerEmail: "sandbox@supportflow.ai"
        })
      });
      const data = await res.json();
      if (data.success) {
        setPlayResult(data.ticket.aiAnalysis);
      }
    } catch (err) {
      console.error("Error processing quick sandbox AI run:", err);
    } finally {
      setLoadingPlay(false);
    }
  };

  const samplePrompts = [
    "I was charged twice $49.00 on my invoice #1092, please issue a credit return.",
    "The SSO login redirects to a white page since this morning's update. Urgent error!",
    "Is it possible to export support metrics to standard CSV format?"
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 selection:bg-indigo-500 selection:text-white" id="saas-landing-page">
      {/* Navbar Banner */}
      <nav className="border-b border-slate-200/60 bg-white/80 backdrop-blur-md sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-violet-600 flex items-center justify-center shadow-lg shadow-indigo-200">
              <Sparkles className="text-white w-5 h-5 animate-pulse" />
            </div>
            <span className="font-display font-bold text-xl tracking-tight text-slate-900">
              Support<span className="text-indigo-600">Flow</span><span className="text-indigo-500 font-mono text-xs ml-1 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">AI</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#features" className="hover:text-indigo-600 transition">Features</a>
            <a href="#playground" className="hover:text-indigo-600 transition bg-indigo-50/50 px-2.5 py-1 rounded-md text-indigo-700">AI Playground</a>
            <a href="#pricing" className="hover:text-indigo-600 transition">Pricing</a>
            <a href="#faqs" className="hover:text-indigo-600 transition">FAQs</a>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onStartDemo('customer')}
              className="text-sm font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100/80 px-4.5 py-2.5 rounded-xl transition cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={() => onStartDemo('admin')}
              className="text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 shadow-md shadow-indigo-100 px-5 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 active:scale-95"
            >
              <span>Launch Console</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="relative pt-12 pb-24 px-6 overflow-hidden">
        {/* Glow Spheres */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-indigo-200/30 rounded-full blur-3xl -z-10"></div>
        <div className="absolute top-1/2 left-10 w-[200px] h-[200px] bg-violet-200/40 rounded-full blur-3xl -z-10"></div>

        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 rounded-full text-indigo-700 text-xs font-semibold mb-6 border border-indigo-100">
            <Zap className="w-3.5 h-3.5 fill-indigo-100 animate-bounce" />
            <span>Next-Gen Helpdesk for Modern Enterprise Teams</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-display font-extrabold tracking-tight text-slate-950 leading-[1.1] mb-6">
            Resolve Customer Tickets <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-600 bg-clip-text text-transparent">
              10x Faster with Gemini AI
            </span>
          </h1>

          <p className="text-slate-600 text-base sm:text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
            SupportFlow AI automatically summarizes customer issues, detects core sentiment mood, drafts empathetic support resolutions, and routes department assignments instantly using advanced LLM reasoning.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <button
              onClick={() => onStartDemo('admin')}
              className="w-full sm:w-auto text-base font-semibold text-white bg-slate-900 hover:bg-slate-800 shadow-xl px-8 py-4 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <span>Log in as Admin</span>
              <span className="bg-slate-700 text-[10px] font-mono uppercase px-1.5 py-0.5 rounded font-bold">Try Now</span>
            </button>
            <button
              onClick={() => onStartDemo('customer')}
              className="w-full sm:w-auto text-base font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 shadow-sm px-8 py-4 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Submit Ticket as Customer</span>
            </button>
          </div>
        </div>

        {/* Dashboard Visual Mockup */}
        <div className="max-w-6xl mx-auto rounded-2xl bg-white border border-slate-200 shadow-2xl p-4 sm:p-6 overflow-hidden relative">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-red-400 rounded-full"></span>
              <span className="w-3 h-3 bg-yellow-400 rounded-full"></span>
              <span className="w-3 h-3 bg-green-400 rounded-full"></span>
              <span className="text-xs text-slate-400 font-mono ml-2">https://supportflow.ai/dashboard</span>
            </div>
            <span className="text-xs bg-indigo-50 text-indigo-700 font-semibold px-2 py-0.5 rounded-full">Sarah Connor (Admin Dashboard)</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 text-left">
            {/* Stats */}
            <div className="md:col-span-4 space-y-4">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-xs text-slate-500 font-medium">AVERAGE RESPONSE TIME</span>
                <div className="text-2xl font-bold text-slate-800 mt-1">14 Minutes</div>
                <div className="text-xs text-emerald-600 font-medium mt-1">↓ 82% compared to last week</div>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-xs text-slate-500 font-medium">CSAT SATISFACTION INDEX</span>
                <div className="text-2xl font-bold text-slate-800 mt-1">4.8 / 5.0</div>
                <div className="text-xs text-emerald-600 font-medium mt-1">↑ 4% improvement with AI suggestions</div>
              </div>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-xs text-slate-500 font-medium">AUTO-TRIAGE SPEED</span>
                <div className="text-2xl font-bold text-slate-800 mt-1">Real-Time</div>
                <div className="text-xs text-indigo-600 font-medium mt-1">Powered by gemini-3.5-flash</div>
              </div>
            </div>

            {/* Simulated Live Ticket Card */}
            <div className="md:col-span-8 p-5 bg-gradient-to-br from-indigo-50/60 to-violet-50/40 rounded-xl border border-indigo-100/80">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs uppercase bg-red-100 text-red-700 font-bold px-2 py-0.5 rounded-full">Urgent Prediction</span>
                  <h3 className="font-semibold text-lg text-slate-900 mt-2">API Connection Interrupted - Status 502 Bad Gateway</h3>
                </div>
                <span className="text-xs text-slate-500">2 minutes ago</span>
              </div>
              <p className="text-sm text-slate-600 mt-3 line-clamp-2">
                We are receiving recurrent 502 status errors whenever our automated sync webhook dispatches to billing pipelines. It completely blocks subscriptions...
              </p>

              <div className="mt-5 pt-4 border-t border-slate-200/80">
                <div className="flex items-center gap-2 text-xs font-semibold text-indigo-900 bg-indigo-100/50 p-2.5 rounded-lg border border-indigo-200/40">
                  <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span>AI Sentiment: Angry (Confidence Index 97%) • Auto-Route: Engineering Department</span>
                </div>
                <div className="mt-3 bg-white border border-slate-200 rounded-lg p-3 text-xs text-slate-700 italic shadow-sm relative">
                  <span className="absolute -top-2 right-4 bg-indigo-600 text-white text-[9px] font-mono px-1.5 rounded font-bold uppercase shadow">Gemini Email Suggestion</span>
                  <p className="font-medium text-slate-800 not-italic">Draft Response:</p>
                  <p className="mt-1">"Hi Alex, We apologize for this gateway interruption. Our engineering stack has flagged a webhook latency issue on the database path..."</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Real-time AI Playground Sandbox Section */}
      <section id="playground" className="py-20 px-6 bg-slate-900 text-white relative">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-xs uppercase font-mono tracking-widest text-indigo-400 bg-indigo-950/80 border border-indigo-900/40 px-3 py-1 rounded-full font-bold">EXPERIENCE THE LLM ENGINE</span>
            <h2 className="text-3xl sm:text-4xl font-display font-bold mt-3">Live Interactive Sandbox</h2>
            <p className="text-slate-400 text-sm mt-2">Type any technical or angry customer issue below to see real-time Gemini AI analysis and responses!</p>
          </div>

          <div className="bg-slate-950 rounded-2xl border border-slate-800 p-6 shadow-2xl">
            <form onSubmit={handleQuickPlay} className="space-y-4">
              <label className="block text-sm text-slate-300 font-medium">Enter Customer Complaint / Message:</label>
              <textarea
                value={playPrompt}
                onChange={(e) => setPlayPrompt(e.target.value)}
                rows={3}
                placeholder="e.g., I ordered a product on Sunday but my premium seat is still showing locked. Also, customer care didn't answer."
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              />

              <div className="flex flex-wrap gap-2">
                {samplePrompts.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setPlayPrompt(p)}
                    className="text-xs bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-800/80 transition cursor-pointer"
                  >
                    "{p.substring(0, 45)}..."
                  </button>
                ))}
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={loadingPlay}
                  className="bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-sm font-semibold px-6 py-3 rounded-xl transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {loadingPlay ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Gemini Analyzing...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Run AI Analysis</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* AI Real-time Output Panel */}
            {playResult && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 p-5 bg-slate-900 rounded-xl border border-indigo-900/40 space-y-4 text-left"
              >
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold bg-indigo-950 text-indigo-400 px-2.5 py-1 rounded-md border border-indigo-900/30">ANALYSIS STATUS : OK</span>
                    <span className="text-xs text-slate-400 font-mono">Confidence Level {playResult.confidenceScore}%</span>
                  </div>
                  <span className={`text-xs uppercase px-2.5 py-1 rounded-full font-bold ${
                    playResult.sentiment === 'Frustrated' || playResult.sentiment === 'Angry'
                      ? "bg-red-500/10 text-red-400 border border-red-500/20"
                      : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                  }`}>
                    Sentiment: {playResult.sentiment}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-300">
                  <div>
                    <span className="text-xs text-slate-500 block">AI GENERATED SUMMARY:</span>
                    <p className="mt-1 text-slate-200 italic font-sans">"{playResult.summary}"</p>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">TRIAGE PREDICTIONS:</span>
                    <div className="mt-1 flex flex-wrap gap-2 text-xs font-mono">
                      <span className="bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md">Priority: {playResult.predictedPriority?.toUpperCase()}</span>
                      <span className="bg-slate-800 text-slate-300 px-2.5 py-1 rounded-md">Dept: {playResult.suggestedDepartment}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-lg p-4">
                  <span className="text-xs text-indigo-400 font-mono block mb-2">AUTO-GENERATED RECONCILIATION EMAIL DRAFT:</span>
                  <pre className="text-xs sm:text-sm text-slate-300 whitespace-pre-wrap font-sans leading-relaxed">
                    {playResult.suggestedSolution}
                  </pre>
                </div>

                <div className="text-xs font-mono text-slate-500 flex flex-wrap items-center gap-2">
                  <span>Detected tags:</span>
                  {playResult.tags?.map((t: string, i: number) => (
                    <span key={i} className="bg-slate-800/80 text-indigo-300 px-2 rounded">{t}</span>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Main Feature Cards */}
      <section id="features" className="py-24 px-6 max-w-7xl mx-auto text-center relative">
        <span className="text-xs text-indigo-600 font-bold uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-full">CORE SAAS FEATURES</span>
        <h2 className="text-3xl sm:text-5xl font-display font-bold text-slate-950 mt-3 mb-16">
          Everything you need to automate helpdesk ops
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-md">
            <div className="h-12 w-12 bg-indigo-50 rounded-xl text-indigo-600 flex items-center justify-center mb-6">
              <Activity className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-3">Instant Sentiment Tracker</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Gemini reads customer descriptions to analyze negative, frustrated, or positive emotional indexes, enabling immediate VIP escalation and smart priority prediction.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-md">
            <div className="h-12 w-12 bg-violet-50 rounded-xl text-violet-600 flex items-center justify-center mb-6">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-3">Auto Smart Reply Drafts</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Generates empathetic and highly precise technical debugging replies in real-time. Admins can view, modify, or send drafts in one single click.
            </p>
          </div>

          <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-md">
            <div className="h-12 w-12 bg-emerald-50 rounded-xl text-emerald-600 flex items-center justify-center mb-6">
              <BarChart2 className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-3">Full Analytics & Exports</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              Track active monthly support volumes, average response times, and sentiment distributions on interactive charts. Export comprehensive logs reports in text layouts.
            </p>
          </div>
        </div>
      </section>

      {/* Pricing Plans */}
      <section id="pricing" className="py-20 px-6 bg-slate-50 border-t border-slate-200/50">
        <div className="max-w-7xl mx-auto text-center">
          <span className="text-xs text-indigo-600 font-bold uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-full">FLEXIBLE PRICING</span>
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-slate-950 mt-3 mb-16">Plans for Every Scale</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto text-left">
            {/* Standard */}
            <div className="bg-white p-8 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-lg text-slate-900">Free Trial</h3>
                <p className="text-xs text-slate-500 mt-1">Perfect to experience sandbox integrations.</p>
                <div className="text-3xl font-extrabold text-slate-900 mt-6">$0<span className="text-sm font-medium text-slate-500">/mo</span></div>
                <ul className="space-y-3.5 mt-8 text-sm text-slate-600">
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Auto-Triage Tickets</li>
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Basic Sentiment Analysis</li>
                  <li className="flex items-center gap-2 text-slate-400 line-through"><CheckCircle className="w-4 h-4 text-slate-300" /> Premium Gemini-2.5 Support</li>
                  <li className="flex items-center gap-2 text-slate-400 line-through"><CheckCircle className="w-4 h-4 text-slate-300" /> Custom domain authentication</li>
                </ul>
              </div>
              <button onClick={() => onStartDemo('customer')} className="mt-8 w-full bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold py-3 rounded-xl transition cursor-pointer">Start Free</button>
            </div>

            {/* Premium */}
            <div className="bg-white p-8 rounded-2xl border-2 border-indigo-600 shadow-md relative flex flex-col justify-between">
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[10px] uppercase font-bold px-3 py-1 rounded-full tracking-widest">MOST POPULAR</span>
              <div>
                <h3 className="font-bold text-lg text-slate-900">Growth Pro</h3>
                <p className="text-xs text-slate-500 mt-1">For active fast-growing SaaS operations.</p>
                <div className="text-3xl font-extrabold text-slate-900 mt-6">$49<span className="text-sm font-medium text-slate-500">/mo</span></div>
                <ul className="space-y-3.5 mt-8 text-sm text-slate-600">
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Unlimited AI analysis runs</li>
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Full Sentiment & Sentiment routing</li>
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Smart reply email dispatcher</li>
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Custom SLA notifications triggers</li>
                </ul>
              </div>
              <button onClick={() => onStartDemo('admin')} className="mt-8 w-full bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold py-3 rounded-xl transition cursor-pointer">Go Pro</button>
            </div>

            {/* Enterprise */}
            <div className="bg-white p-8 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-lg text-slate-900">Enterprise Core</h3>
                <p className="text-xs text-slate-500 mt-1">For maximum SLA guarantee & SLAs policies.</p>
                <div className="text-3xl font-extrabold text-slate-900 mt-6">$199<span className="text-sm font-medium text-slate-500">/mo</span></div>
                <ul className="space-y-3.5 mt-8 text-sm text-slate-600">
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Everything in Pro plan</li>
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Multi-region dedicated nodes</li>
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Active 24/7 priority call desk</li>
                  <li className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-500" /> Direct Slack API integrations</li>
                </ul>
              </div>
              <button onClick={() => onStartDemo('admin')} className="mt-8 w-full bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold py-3 rounded-xl transition cursor-pointer">Contact Sales</button>
            </div>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions */}
      <section id="faqs" className="py-24 px-6 max-w-4xl mx-auto text-left">
        <h2 className="text-3xl font-display font-bold text-slate-950 text-center mb-12">Frequently Asked Questions</h2>
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200/60">
            <h4 className="font-bold text-slate-900">How accurate is the Gemini support sentiment analysis?</h4>
            <p className="text-sm text-slate-600 mt-2">The analysis achieves over 95% accuracy in identifying frustration or technical errors by using precise JSON parsing schemas from Google Gemini 3.5 models. It correctly routes billing and technical inquiries.</p>
          </div>
          <div className="bg-white p-6 rounded-xl border border-slate-200/60">
            <h4 className="font-bold text-slate-900">Can support agents override or rejection suggested AI replies?</h4>
            <p className="text-sm text-slate-600 mt-2">Absolutely. The Admin Console allows authorized agents to review the generated response draft, edit it as they see fit, accept and send it, or completely discard it.</p>
          </div>
          <div className="bg-white p-6 rounded-xl border border-slate-200/60">
            <h4 className="font-bold text-slate-900">What Laravel technologies are used for this stack?</h4>
            <p className="text-sm text-slate-600 mt-2">The actual backend blueprints export incorporates Laravel 12 features like constructor promotion, custom service singletons for Gemini API HTTP dispatching, database queues to process AI reports asynchronously, and Blade views.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-12 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-slate-900 text-sm">SupportFlow AI</span>
            <span>• Built for interviews & live SaaS evaluations</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400 font-medium">
            <a href="#features" className="hover:text-slate-600">Features</a>
            <a href="#playground" className="hover:text-slate-600">Sandbox</a>
            <a href="#pricing" className="hover:text-slate-600">Pricing</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
