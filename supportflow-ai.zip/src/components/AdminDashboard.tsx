/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Ticket, Comment, User, ActivityLog } from "../types";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell 
} from "recharts";
import { 
  Sparkles, CheckCircle, Clock, Trash2, Edit2, UserPlus, ShieldAlert, Check, X,
  Search, Filter, Plus, Shield, Users, MessageCircle, ArrowRight, UserCheck, AlertOctagon, HelpCircle,
  BarChart2, Code, LogOut, RefreshCw
} from "lucide-react";

interface AdminDashboardProps {
  user: { id: string; name: string; email: string; role: string; avatar?: string };
  onLogout: () => void;
  onGoToLaravel: () => void;
}

export default function AdminDashboard({ user, onLogout, onGoToLaravel }: AdminDashboardProps) {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  
  // Tab views
  const [activeTab, setActiveTab] = useState<'tickets' | 'users' | 'analytics'>('tickets');
  
  // Selected detail states
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [ticketDetails, setTicketDetails] = useState<Ticket | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);

  // Search/Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [deptFilter, setDeptFilter] = useState("all");

  // User manager form states
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [userRole, setUserRole] = useState<'admin' | 'agent' | 'customer'>('customer');

  // Interactive AI Reply editor
  const [aiResponseText, setAiResponseText] = useState("");
  const [editingAiReply, setEditingAiReply] = useState(false);

  // Fetch admin state data
  const fetchData = async () => {
    try {
      const ticketsRes = await fetch("/api/tickets");
      const ticketsData = await ticketsRes.json();
      setTickets(ticketsData);

      const usersRes = await fetch("/api/users");
      const usersData = await usersRes.json();
      setUsersList(usersData);

      const analyticsRes = await fetch("/api/analytics");
      const analyticsData = await analyticsRes.json();
      setAnalytics(analyticsData);
    } catch (err) {
      console.error("Error loading administrative states:", err);
    }
  };

  const loadTicketDetails = async (id: string) => {
    try {
      const res = await fetch(`/api/tickets/${id}`);
      const data = await res.json();
      setTicketDetails(data.ticket);
      setComments(data.comments);
      setLogs(data.logs);
      if (data.ticket.aiAnalysis) {
        setAiResponseText(data.ticket.aiAnalysis.suggestedSolution);
      }
    } catch (err) {
      console.error("Error loading details for ticket id:", id, err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (selectedTicketId) {
      loadTicketDetails(selectedTicketId);
    }
  }, [selectedTicketId]);

  // AI Actions: Accept, Edit, or Reject suggestions
  const handleAiAction = async (action: 'accept' | 'reject' | 'edit') => {
    if (!selectedTicketId) return;

    try {
      const res = await fetch(`/api/tickets/${selectedTicketId}/ai-action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action,
          editedReply: action === 'edit' ? aiResponseText : undefined
        })
      });
      const data = await res.json();
      if (data.success) {
        setEditingAiReply(false);
        fetchData();
        loadTicketDetails(selectedTicketId);
      }
    } catch (err) {
      console.error("Failed to dispatcher AI action:", err);
    }
  };

  // Change Ticket Assignment or Status manually
  const handleUpdateTicketMeta = async (fields: any) => {
    if (!selectedTicketId) return;

    try {
      const res = await fetch(`/api/tickets/${selectedTicketId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(fields)
      });
      const data = await res.json();
      if (data.success) {
        fetchData();
        loadTicketDetails(selectedTicketId);
      }
    } catch (err) {
      console.error("Error updating ticket metadata details:", err);
    }
  };

  // User Profiles Management
  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !userEmail.trim()) return;

    try {
      const method = editingUserId ? "PUT" : "POST";
      const endpoint = editingUserId ? `/api/users/${editingUserId}` : "/api/auth/register";
      
      const res = await fetch(endpoint, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: userName,
          email: userEmail,
          role: userRole
        })
      });
      const data = await res.json();
      if (data.success) {
        setUserName("");
        setUserEmail("");
        setEditingUserId(null);
        setShowUserModal(false);
        fetchData();
      }
    } catch (err) {
      console.error("Error saving user profile details:", err);
    }
  };

  const handleEditUserClick = (usr: User) => {
    setEditingUserId(usr.id);
    setUserName(usr.name);
    setUserEmail(usr.email);
    setUserRole(usr.role);
    setShowUserModal(true);
  };

  const handleDeleteUser = async (id: string) => {
    if (!confirm("Remove this user profile and invalidate related access keys?")) return;
    try {
      await fetch(`/api/users/${id}`, { method: "DELETE" });
      fetchData();
    } catch (err) {
      console.error("Error removing user:", err);
    }
  };

  const COLORS = ['#6366f1', '#a855f7', '#10b981', '#f59e0b', '#ef4444'];

  const filteredTickets = tickets.filter(t => {
    const matchesSearch = t.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === "all" || t.status === statusFilter;
    const matchesPriority = priorityFilter === "all" || t.priority === priorityFilter;
    const matchesDept = deptFilter === "all" || t.department === deptFilter;

    return matchesSearch && matchesStatus && matchesPriority && matchesDept;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row" id="admin-dashboard-root">
      {/* Sidebar Control Panel */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex flex-col justify-between shrink-0">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-8">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-tr from-indigo-500 to-violet-600 flex items-center justify-center">
              <Sparkles className="text-white w-4.5 h-4.5" />
            </div>
            <span className="font-display font-bold text-lg text-white">SupportFlow AI</span>
          </div>

          <div className="space-y-1">
            <button
              onClick={() => setActiveTab('tickets')}
              className={`w-full flex items-center gap-3 p-3 rounded-xl text-left text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'tickets' ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/10" : "text-slate-400 hover:text-white"
              }`}
            >
              <MessageCircle className="w-4.5 h-4.5" />
              <span>Manage Tickets</span>
              <span className="ml-auto bg-slate-800 text-[10px] text-indigo-300 font-bold px-1.5 py-0.5 rounded-full">
                {tickets.filter(t => t.status === 'open').length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('users')}
              className={`w-full flex items-center gap-3 p-3 rounded-xl text-left text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'users' ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/10" : "text-slate-400 hover:text-white"
              }`}
            >
              <Users className="w-4.5 h-4.5" />
              <span>Manage Users</span>
            </button>

            <button
              onClick={() => setActiveTab('analytics')}
              className={`w-full flex items-center gap-3 p-3 rounded-xl text-left text-sm font-medium transition-all cursor-pointer ${
                activeTab === 'analytics' ? "bg-indigo-600 text-white shadow-md shadow-indigo-950/10" : "text-slate-400 hover:text-white"
              }`}
            >
              <BarChart2 className="w-4.5 h-4.5" />
              <span>SaaS Analytics</span>
            </button>

            <div className="pt-6 mt-6 border-t border-slate-800 space-y-2">
              <span className="text-[10px] font-mono text-slate-500 tracking-wider uppercase font-bold block px-3">Developer Center</span>
              <button
                onClick={onGoToLaravel}
                className="w-full flex items-center gap-3 p-3 rounded-xl text-left text-xs text-rose-400 hover:bg-slate-800/60 font-medium transition cursor-pointer"
              >
                <Code className="w-4.5 h-4.5" />
                <span>Laravel 12 Code Blueprints</span>
              </button>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-slate-800">
          <div className="flex items-center gap-3 mb-4 bg-slate-800/40 p-2 rounded-lg">
            <img src={user.avatar || "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120"} alt="" className="w-8 h-8 rounded-full border border-slate-700" />
            <div>
              <div className="text-xs font-semibold truncate max-w-[120px]">{user.name}</div>
              <div className="text-[9px] uppercase font-bold text-rose-400">Security: Admin</div>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-2 text-slate-400 hover:text-white transition text-xs font-medium cursor-pointer"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>Close Session</span>
          </button>
        </div>
      </aside>

      {/* Main Panel Content */}
      <main className="flex-1 flex flex-col overflow-hidden text-left">
        {/* Header metrics summary block */}
        <header className="bg-white border-b border-slate-200/80 p-5 px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-display font-bold text-slate-900">Support Operations Desk</h1>
            <p className="text-slate-500 text-xs mt-0.5">Approve Gemini AI predictions, monitor queue statuses, and control access permissions.</p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono bg-indigo-50/50 p-2.5 rounded-xl border border-indigo-100/30">
            <div className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-indigo-600" />
              <span className="text-indigo-900 font-semibold">Avg SLA SLA: 14m</span>
            </div>
            <div className="h-4 w-px bg-indigo-200"></div>
            <div className="flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5 text-indigo-600" />
              <span className="text-indigo-900 font-semibold">CSAT Index: {analytics?.metrics?.avgSatisfaction || "4.8"}/5.0</span>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 max-w-7xl w-full mx-auto">
          {activeTab === 'tickets' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Tickets Directory list with filters */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200/50 space-y-3.5 shadow-sm">
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search title, user, tag..."
                      className="w-full text-xs border border-slate-200 pl-9.5 pr-4 py-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="space-y-1 text-xs">
                    <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Filter parameters</span>
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="border border-slate-200 p-2 rounded-lg bg-white focus:outline-none"
                      >
                        <option value="all">All Statuses</option>
                        <option value="open">Open</option>
                        <option value="assigned">Assigned</option>
                        <option value="resolved">Resolved</option>
                        <option value="closed">Closed</option>
                      </select>
                      <select
                        value={priorityFilter}
                        onChange={(e) => setPriorityFilter(e.target.value)}
                        className="border border-slate-200 p-2 rounded-lg bg-white focus:outline-none"
                      >
                        <option value="all">All Priority</option>
                        <option value="low">Low</option>
                        <option value="medium">Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Queue Cards scroll area */}
                <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
                  {filteredTickets.length === 0 ? (
                    <div className="text-center p-8 bg-white border border-slate-100 rounded-xl">
                      <p className="text-slate-400 text-xs">No support tickets found.</p>
                    </div>
                  ) : (
                    filteredTickets.map((t) => (
                      <div
                        key={t.id}
                        onClick={() => setSelectedTicketId(t.id)}
                        className={`p-4 bg-white rounded-xl border transition-all cursor-pointer text-left relative overflow-hidden ${
                          selectedTicketId === t.id
                            ? "border-indigo-600 shadow-md ring-1 ring-indigo-500/10"
                            : "border-slate-200 hover:border-slate-300"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono uppercase font-bold text-slate-400">ID: {t.id}</span>
                          <span className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-full ${
                            t.priority === 'urgent' ? "bg-red-100 text-red-800" :
                            t.priority === 'high' ? "bg-amber-100 text-amber-800" :
                            "bg-slate-100 text-slate-800"
                          }`}>
                            {t.priority}
                          </span>
                        </div>

                        <h4 className="font-semibold text-slate-900 text-sm mt-2 line-clamp-1">{t.title}</h4>
                        <p className="text-xs text-slate-500 mt-0.5 font-medium">Customer: {t.customerName}</p>

                        <div className="flex items-center justify-between mt-3.5 pt-2.5 border-t border-slate-100/80 text-[10px] text-slate-400 font-mono">
                          <span className="text-indigo-600 font-semibold">{t.department}</span>
                          <span className={`text-[9px] font-bold ${
                            t.status === 'open' ? 'text-amber-500' :
                            t.status === 'assigned' ? 'text-blue-500' :
                            'text-emerald-500'
                          }`}>{t.status.toUpperCase()}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Multi-Module Triage & AI suggestions Center */}
              <div className="lg:col-span-8">
                {ticketDetails ? (
                  <div className="bg-white rounded-2xl border border-slate-200/60 shadow-md overflow-hidden flex flex-col justify-between min-h-[550px]">
                    {/* Header */}
                    <div className="p-5 border-b border-slate-200/80 bg-slate-50/50">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div>
                          <span className="text-xs bg-indigo-50 text-indigo-700 font-mono px-2 py-0.5 rounded">REF: {ticketDetails.id}</span>
                          <span className="text-xs text-slate-500 font-mono ml-2">Subby: {ticketDetails.customerName} ({ticketDetails.customerEmail})</span>
                        </div>

                        {/* Assign and status controllers */}
                        <div className="flex items-center gap-2">
                          <select
                            value={ticketDetails.status}
                            onChange={(e) => handleUpdateTicketMeta({ status: e.target.value })}
                            className="text-xs border border-slate-200 p-1.5 rounded-md bg-white focus:outline-none"
                          >
                            <option value="open">Open</option>
                            <option value="assigned">Assigned</option>
                            <option value="resolved">Resolved</option>
                            <option value="closed">Closed</option>
                          </select>

                          <select
                            value={ticketDetails.assignedStaffId || ""}
                            onChange={(e) => {
                              const targetAgent = usersList.find(u => u.id === e.target.value);
                              handleUpdateTicketMeta({
                                assignedStaffId: e.target.value || null,
                                assignedStaffName: targetAgent ? targetAgent.name : null
                              });
                            }}
                            className="text-xs border border-slate-200 p-1.5 rounded-md bg-white focus:outline-none"
                          >
                            <option value="">Assign Agent...</option>
                            {usersList.filter(u => u.role === 'agent').map(agent => (
                              <option key={agent.id} value={agent.id}>{agent.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <h3 className="font-display font-bold text-lg text-slate-900 mt-4">{ticketDetails.title}</h3>
                      <p className="text-xs text-slate-500 mt-2 whitespace-pre-wrap bg-slate-100 p-3.5 rounded-xl border border-slate-200/40">{ticketDetails.description}</p>
                    </div>

                    {/* AI REVELATIONS / SUGGESTIONS DRAWER */}
                    {ticketDetails.aiAnalysis && (
                      <div className="p-5 border-b border-indigo-100 bg-gradient-to-br from-indigo-50/40 to-violet-50/20 space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-indigo-100 pb-3">
                          <div className="flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-indigo-600" />
                            <h4 className="font-display font-bold text-sm text-indigo-950">Gemini AI Auto-Triage Prediction Summary</h4>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-mono bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-md">Sentiment Confidence: {ticketDetails.aiAnalysis.confidenceScore}%</span>
                            <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-md ${
                              ticketDetails.aiAnalysis.sentiment === 'Angry' || ticketDetails.aiAnalysis.sentiment === 'Frustrated'
                                ? "bg-red-100 text-red-700"
                                : "bg-emerald-100 text-emerald-700"
                            }`}>Sentiment: {ticketDetails.aiAnalysis.sentiment}</span>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                          <div className="bg-white/80 border border-indigo-100/60 p-3 rounded-xl">
                            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">Auto Issue Abstract</span>
                            <p className="mt-1 text-slate-700 italic">"{ticketDetails.aiAnalysis.summary}"</p>
                          </div>
                          <div className="bg-white/80 border border-indigo-100/60 p-3 rounded-xl">
                            <span className="text-[10px] font-mono uppercase text-slate-400 font-bold">Recommended Department Route</span>
                            <div className="mt-2 flex items-center justify-between">
                              <span className="text-indigo-700 font-bold">{ticketDetails.aiAnalysis.suggestedDepartment}</span>
                              <button
                                onClick={() => handleUpdateTicketMeta({ department: ticketDetails.aiAnalysis?.suggestedDepartment })}
                                className="text-[9px] font-mono bg-indigo-600 text-white font-bold px-2 py-0.5 rounded cursor-pointer"
                              >
                                Route Route
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Response suggested draft */}
                        <div className="bg-white border border-indigo-100/80 rounded-xl p-4 shadow-sm relative text-slate-800">
                          <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
                            <span className="text-[10px] font-mono text-indigo-600 font-bold">GEMINI GENERATED DRAFT RESPONSE RECONCILIATION</span>
                            {ticketDetails.aiAnalysis.status === 'pending' ? (
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => setEditingAiReply(!editingAiReply)}
                                  className="text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-600 px-2.5 py-1 rounded cursor-pointer font-semibold"
                                >
                                  {editingAiReply ? "Disable Editing" : "Edit Draft"}
                                </button>
                                <button
                                  onClick={() => handleAiAction('reject')}
                                  className="text-[10px] bg-rose-50 hover:bg-rose-100 text-rose-600 px-2.5 py-1 rounded cursor-pointer font-semibold"
                                >
                                  Reject Suggested
                                </button>
                                <button
                                  onClick={() => handleAiAction(editingAiReply ? 'edit' : 'accept')}
                                  className="text-[10px] bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1 rounded cursor-pointer font-bold flex items-center gap-1 shadow-sm"
                                >
                                  <Check className="w-3 h-3" />
                                  <span>Send Solution</span>
                                </button>
                              </div>
                            ) : (
                              <span className="text-[10px] font-mono uppercase bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">Action completed : {ticketDetails.aiAnalysis.status}</span>
                            )}
                          </div>

                          {editingAiReply ? (
                            <textarea
                              value={aiResponseText}
                              onChange={(e) => setAiResponseText(e.target.value)}
                              rows={5}
                              className="w-full text-xs border border-slate-200 p-2 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                            />
                          ) : (
                            <pre className="text-xs font-sans whitespace-pre-wrap leading-relaxed italic text-slate-600">
                              {ticketDetails.aiAnalysis.status === 'edited' ? ticketDetails.aiAnalysis.editedReply : ticketDetails.aiAnalysis.suggestedSolution}
                            </pre>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Chat Logs Trail list */}
                    <div className="p-5 flex-1 max-h-[220px] overflow-y-auto space-y-3.5 border-b border-slate-100">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Interactive History & Comments</span>
                      {comments.length === 0 ? (
                        <p className="text-xs text-slate-400">No communication logs recorded yet.</p>
                      ) : (
                        comments.map((c) => (
                          <div key={c.id} className="text-xs flex gap-2">
                            <span className="font-bold text-slate-700">{c.senderName}:</span>
                            <span className="text-slate-600">{c.message}</span>
                            <span className="text-[9px] text-slate-400 ml-auto font-mono">{new Date(c.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Manual reply entry form */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        const msgInput = (e.target as any).message.value;
                        if (!msgInput.trim()) return;
                        fetch(`/api/tickets/${ticketDetails.id}/comments`, {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({
                            senderId: user.id,
                            senderName: user.name,
                            senderRole: "admin",
                            message: msgInput
                          })
                        }).then(() => {
                          (e.target as any).reset();
                          loadTicketDetails(ticketDetails.id);
                        });
                      }}
                      className="p-4 bg-slate-50 flex items-center gap-3"
                    >
                      <input
                        type="text"
                        name="message"
                        placeholder="Type manual staff reply here..."
                        className="flex-1 bg-white border border-slate-200 text-xs p-2.5 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                      <button type="submit" className="bg-slate-900 text-white text-xs px-4 py-2.5 rounded-lg font-semibold hover:bg-slate-800 transition shrink-0 cursor-pointer">
                        Send Reply
                      </button>
                    </form>
                  </div>
                ) : (
                  <div className="bg-white rounded-2xl border border-slate-200/50 shadow-sm min-h-[450px] flex flex-col items-center justify-center p-8 text-center text-slate-400">
                    <ShieldAlert className="w-12 h-12 text-indigo-300 mb-3" />
                    <h3 className="font-bold text-slate-700 text-sm font-display">Select active ticket from the directory</h3>
                    <p className="text-xs max-w-xs mt-1 leading-relaxed">Select any complaint. You can evaluate sentiment indices, override suggested smart resolutions drafts, and route tickets to developer teams.</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            /* User Profiles Management Tab */
            <div className="bg-white rounded-2xl border border-slate-200/60 p-6 shadow-md text-left space-y-6">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-slate-900">User Configuration Directory</h3>
                  <p className="text-slate-500 text-xs mt-0.5">Control employee authorization, manage support desks, and modify profiles.</p>
                </div>
                <button
                  onClick={() => {
                    setEditingUserId(null);
                    setUserName("");
                    setUserEmail("");
                    setUserRole("customer");
                    setShowUserModal(true);
                  }}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 rounded-lg transition flex items-center gap-1.5 cursor-pointer shadow"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Register Employee Profile</span>
                </button>
              </div>

              {/* Table list of Users */}
              <div className="overflow-x-auto rounded-xl border border-slate-200/60">
                <table className="w-full text-sm text-left text-slate-600">
                  <thead className="text-xs uppercase font-mono bg-slate-50 text-slate-500 border-b border-slate-200">
                    <tr>
                      <th className="p-4 font-semibold">Name & Description</th>
                      <th className="p-4 font-semibold">User Email</th>
                      <th className="p-4 font-semibold">Assigned Role</th>
                      <th className="p-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {usersList.map((usr) => (
                      <tr key={usr.id} className="hover:bg-slate-50/50 transition">
                        <td className="p-4 font-medium text-slate-900 flex items-center gap-3">
                          <img src={usr.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=120"} alt="" className="w-8 h-8 rounded-full border border-slate-200" />
                          <span>{usr.name}</span>
                        </td>
                        <td className="p-4 font-mono text-xs">{usr.email}</td>
                        <td className="p-4">
                          <span className={`text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full ${
                            usr.role === 'admin' ? "bg-rose-100 text-rose-800" :
                            usr.role === 'agent' ? "bg-indigo-100 text-indigo-800" :
                            "bg-slate-100 text-slate-800"
                          }`}>
                            {usr.role}
                          </span>
                        </td>
                        <td className="p-4 text-right space-x-2">
                          <button
                            onClick={() => handleEditUserClick(usr)}
                            className="p-1.5 hover:bg-slate-100 rounded transition text-slate-500 hover:text-indigo-600 cursor-pointer"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteUser(usr.id)}
                            className="p-1.5 hover:bg-slate-100 rounded transition text-slate-400 hover:text-rose-500 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
            /* SaaS Analytics Dashboard Graphs */
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-xl border border-slate-200/50 shadow-sm text-left">
                  <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Total SaaS Complaints</span>
                  <div className="text-3xl font-extrabold text-slate-900 mt-2">{tickets.length}</div>
                  <p className="text-[10px] text-emerald-600 font-medium mt-1">↑ Active tickets volume matching SLA limits</p>
                </div>
                <div className="bg-white p-5 rounded-xl border border-slate-200/50 shadow-sm text-left">
                  <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Open In-Queue Issues</span>
                  <div className="text-3xl font-extrabold text-amber-600 mt-2">{tickets.filter(t => t.status === 'open').length}</div>
                  <p className="text-[10px] text-slate-500 font-medium mt-1">Requires triage & routing dispatch</p>
                </div>
                <div className="bg-white p-5 rounded-xl border border-slate-200/50 shadow-sm text-left">
                  <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Resolved Ticket Ops</span>
                  <div className="text-3xl font-extrabold text-emerald-600 mt-2">{tickets.filter(t => t.status === 'resolved' || t.status === 'closed').length}</div>
                  <p className="text-[10px] text-emerald-600 font-medium mt-1">Trace record: 100% resolution index</p>
                </div>
                <div className="bg-white p-5 rounded-xl border border-slate-200/50 shadow-sm text-left">
                  <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Avg Satisfaction (CSAT)</span>
                  <div className="text-3xl font-extrabold text-indigo-600 mt-2">{analytics?.metrics?.avgSatisfaction || "4.8"}/5.0</div>
                  <p className="text-[10px] text-indigo-500 font-medium mt-1">Driven by direct feedback rating</p>
                </div>
              </div>

              {/* Dynamic Recharts Visualization Graph Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200/60 p-5 shadow-sm">
                  <h4 className="font-bold text-slate-900 text-sm mb-4">SaaS Complaints Monthly Volumetric Growth</h4>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analytics?.monthlyVolume || []}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="month" tick={{fontSize: 11, fill: '#64748b'}} />
                        <YAxis tick={{fontSize: 11, fill: '#64748b'}} />
                        <Tooltip />
                        <Bar dataKey="count" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200/60 p-5 shadow-sm">
                  <h4 className="font-bold text-slate-900 text-sm mb-4">Support Ticket Category Spread</h4>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={analytics?.categories || [{name: 'Loading', value: 1}]}
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={75}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {(analytics?.categories || []).map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2 text-[10px] font-mono justify-center">
                    {(analytics?.categories || []).map((entry: any, index: number) => (
                      <span key={index} className="flex items-center gap-1">
                        <span className="w-2.5 h-2.5 rounded-full" style={{backgroundColor: COLORS[index % COLORS.length]}}></span>
                        <span>{entry.name} ({entry.value})</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Register/Edit User Modal */}
      {showUserModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl p-6 max-w-md w-full text-left space-y-4">
            <h3 className="font-display font-bold text-lg text-slate-900">
              {editingUserId ? "Edit Employee Profile" : "Register Employee Profile"}
            </h3>
            <p className="text-xs text-slate-500">Provide direct configuration values for roles assignment controls.</p>

            <form onSubmit={handleSaveUser} className="space-y-4">
              <div>
                <label className="block text-xs uppercase font-mono text-slate-500 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="e.g. David Miller"
                  className="w-full border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-slate-500 mb-1">Employee Email Address</label>
                <input
                  type="email"
                  required
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  placeholder="e.g. agent@supportflow.ai"
                  className="w-full border border-slate-200 p-2.5 rounded-xl text-sm focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs uppercase font-mono text-slate-500 mb-1">Assigned Security Role</label>
                <select
                  value={userRole}
                  onChange={(e) => setUserRole(e.target.value as any)}
                  className="w-full border border-slate-200 p-2.5 bg-white rounded-xl text-sm focus:outline-none"
                >
                  <option value="customer">Customer Profile</option>
                  <option value="agent">Support Desk Agent</option>
                  <option value="admin">System Administrator</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUserModal(false)}
                  className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="text-xs bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-5 py-2.5 rounded-xl shadow-md cursor-pointer"
                >
                  Save User Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
