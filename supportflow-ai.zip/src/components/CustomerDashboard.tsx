/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Ticket, Comment, ActivityLog } from "../types";
import { 
  Plus, Search, Filter, Sparkles, Send, FileText, Image as ImageIcon, 
  CheckCircle, ArrowLeft, Clock, MessageSquare, Star, Trash2, Edit2, LogOut, RefreshCw
} from "lucide-react";

interface CustomerDashboardProps {
  user: { id: string; name: string; email: string; role: string; avatar?: string };
  onLogout: () => void;
}

export default function CustomerDashboard({ user, onLogout }: CustomerDashboardProps) {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  
  // Detailed view states
  const [ticketDetails, setTicketDetails] = useState<Ticket | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  
  // Form states
  const [showCreateForm, setShowCreateForm] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newCategory, setNewCategory] = useState("Technical");
  const [newPriority, setNewPriority] = useState("medium");
  const [newScreenshot, setNewScreenshot] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);

  // Filter/Search states
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  // Interaction states
  const [commentText, setCommentText] = useState("");
  const [rating, setRating] = useState<number>(5);
  const [feedbackText, setFeedbackText] = useState("");
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);

  // Fetch customer-specific tickets
  const fetchTickets = async () => {
    try {
      const res = await fetch(`/api/tickets?role=customer&customerId=${user.id}`);
      const data = await res.json();
      setTickets(data);
    } catch (err) {
      console.error("Error loading customer tickets:", err);
    }
  };

  // Fetch ticket detailed comments/logs
  const loadTicketDetails = async (id: string) => {
    try {
      const res = await fetch(`/api/tickets/${id}`);
      const data = await res.json();
      setTicketDetails(data.ticket);
      setComments(data.comments);
      setLogs(data.logs);
    } catch (err) {
      console.error("Error fetching ticket details:", err);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [user.id]);

  useEffect(() => {
    if (selectedTicketId) {
      loadTicketDetails(selectedTicketId);
    }
  }, [selectedTicketId]);

  // Handle image drag & drop or selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Create Ticket
  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newTitle,
          description: newDesc,
          category: newCategory,
          priority: newPriority,
          customerId: user.id,
          customerName: user.name,
          customerEmail: user.email,
          screenshot: newScreenshot
        })
      });
      const data = await res.json();
      if (data.success) {
        setNewTitle("");
        setNewDesc("");
        setNewScreenshot("");
        setShowCreateForm(false);
        fetchTickets();
        // Automatically select the new ticket
        setSelectedTicketId(data.ticket.id);
      }
    } catch (err) {
      console.error("Failed to create ticket:", err);
    } finally {
      setSubmitting(false);
    }
  };

  // Send Reply/Comment
  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !selectedTicketId) return;

    try {
      const res = await fetch(`/api/tickets/${selectedTicketId}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: user.id,
          senderName: user.name,
          senderRole: "customer",
          message: commentText
        })
      });
      const data = await res.json();
      if (data.success) {
        setCommentText("");
        loadTicketDetails(selectedTicketId);
      }
    } catch (err) {
      console.error("Error posting comment:", err);
    }
  };

  // Submit Rating Feedback (Closes Ticket)
  const handleSubmitFeedback = async () => {
    if (!selectedTicketId) return;

    try {
      const res = await fetch(`/api/tickets/${selectedTicketId}/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rating,
          comment: feedbackText
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowFeedbackModal(false);
        setFeedbackText("");
        setRating(5);
        fetchTickets();
        loadTicketDetails(selectedTicketId);
      }
    } catch (err) {
      console.error("Failed to submit feedback:", err);
    }
  };

  // Export report simulated trigger
  const handleExportReport = (ticketId: string) => {
    window.open(`/api/tickets/${ticketId}/export`, "_blank");
  };

  // Delete Own Ticket
  const handleDeleteTicket = async (ticketId: string) => {
    if (!confirm("Are you sure you want to delete this ticket? This action is permanent.")) return;
    try {
      await fetch(`/api/tickets/${ticketId}`, { method: "DELETE" });
      setSelectedTicketId(null);
      setTicketDetails(null);
      fetchTickets();
    } catch (err) {
      console.error("Failed to delete ticket:", err);
    }
  };

  // Filter logic
  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          ticket.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          ticket.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === "all" || ticket.status === statusFilter;
    const matchesCategory = categoryFilter === "all" || ticket.category === categoryFilter;

    return matchesSearch && matchesStatus && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row" id="customer-dashboard">
      {/* Sidebar navigation */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex flex-col justify-between shrink-0">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-8">
            <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center">
              <Sparkles className="text-white w-4.5 h-4.5" />
            </div>
            <span className="font-display font-bold text-lg text-white">SupportFlow AI</span>
          </div>

          <div className="space-y-4">
            <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/50 flex items-center gap-3">
              <img src={user.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=120"} alt="" className="w-10 h-10 rounded-full border border-slate-600" />
              <div>
                <div className="text-sm font-semibold truncate max-w-[120px]">{user.name}</div>
                <div className="text-[10px] uppercase font-bold tracking-wider text-indigo-400">Customer Mode</div>
              </div>
            </div>

            <button
              onClick={() => {
                setShowCreateForm(true);
                setSelectedTicketId(null);
              }}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold py-3 px-4 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-indigo-950/20"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Ticket</span>
            </button>
          </div>
        </div>

        <div className="p-6 border-t border-slate-800">
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-2 text-slate-400 hover:text-white transition text-sm font-medium cursor-pointer"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>Sign Out Session</span>
          </button>
        </div>
      </aside>

      {/* Main Container */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Navbar */}
        <header className="bg-white border-b border-slate-200/80 p-5 px-6 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-display font-bold text-slate-900">My Helpdesk Center</h1>
            <p className="text-slate-500 text-xs mt-0.5">Submit issues, trace AI routing and response solutions drafts.</p>
          </div>
        </header>

        {/* Dynamic Inner Layout */}
        <div className="flex-1 overflow-y-auto p-6 max-w-7xl w-full mx-auto">
          {showCreateForm ? (
            /* Creation Form */
            <div className="max-w-2xl bg-white p-6 rounded-2xl border border-slate-200/60 shadow-md">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <Plus className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-lg font-bold text-slate-900">Create Support Ticket</h2>
                </div>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="text-xs bg-slate-50 hover:bg-slate-100 text-slate-500 px-3 py-1.5 rounded-lg transition"
                >
                  Back to List
                </button>
              </div>

              <form onSubmit={handleCreateTicket} className="space-y-5 text-left">
                <div>
                  <label className="block text-xs uppercase font-mono tracking-wider font-semibold text-slate-500 mb-1.5">Ticket Subject / Title</label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g. Critical double-charge on Invoice #89201"
                    className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs uppercase font-mono tracking-wider font-semibold text-slate-500 mb-1.5">Support Category</label>
                    <select
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full border border-slate-200 rounded-xl p-3 text-sm bg-white focus:outline-none"
                    >
                      <option value="Technical">Technical Support</option>
                      <option value="Billing">Billing & Subscription</option>
                      <option value="Account">Account Security</option>
                      <option value="Feature Request">Feature Request</option>
                      <option value="General">General Inquiry</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs uppercase font-mono tracking-wider font-semibold text-slate-500 mb-1.5">Your Self-Assessed Urgency</label>
                    <select
                      value={newPriority}
                      onChange={(e) => setNewPriority(e.target.value)}
                      className="w-full border border-slate-200 rounded-xl p-3 text-sm bg-white focus:outline-none"
                    >
                      <option value="low">Low - General Question</option>
                      <option value="medium">Medium - Functional Issues</option>
                      <option value="high">High - Serious Blockers</option>
                      <option value="urgent">Urgent - System Outage</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase font-mono tracking-wider font-semibold text-slate-500 mb-1.5">Detailed Issue Description</label>
                  <p className="text-[11px] text-slate-400 mb-1">Explain what you were doing, what failed, and steps to reproduce. AI will automatically evaluate details.</p>
                  <textarea
                    required
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    rows={6}
                    placeholder="Provide full context here..."
                    className="w-full border border-slate-200 rounded-xl p-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                  />
                </div>

                {/* File Upload simulator */}
                <div>
                  <label className="block text-xs uppercase font-mono tracking-wider font-semibold text-slate-500 mb-1.5">Upload Screenshot or Log Document</label>
                  <div className="border-2 border-dashed border-slate-200 hover:border-indigo-400/80 rounded-xl p-4 transition flex flex-col items-center justify-center gap-2 bg-slate-50/50 relative">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <ImageIcon className="w-8 h-8 text-slate-400" />
                    <div className="text-xs font-medium text-slate-600">Select file or Drag & Drop here</div>
                    <div className="text-[10px] text-slate-400">PNG, JPG up to 4MB supported</div>
                  </div>
                  {newScreenshot && (
                    <div className="mt-3 flex items-center gap-3 bg-indigo-50/50 p-2.5 rounded-lg border border-indigo-100/40">
                      <img src={newScreenshot} alt="Preview" className="w-12 h-12 object-cover rounded-md border border-indigo-200" />
                      <div>
                        <span className="text-xs font-semibold text-indigo-900">Attachment Ready</span>
                        <p className="text-[10px] text-slate-400">Image successfully processed into base64 payload.</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-semibold text-sm px-6 py-3 rounded-xl transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {submitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Dispatched to Gemini AI Router...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Submit Ticket with Auto-AI Triage</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          ) : (
            /* Standard Customer layout: Tickets lists and Conversation detail splits */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Ticket list filter section */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200/50 space-y-3 shadow-sm">
                  <div className="relative">
                    <Search className="w-4.5 h-4.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search title, ID, tag..."
                      className="w-full text-xs border border-slate-200 pl-9.5 pr-4 py-2 rounded-lg focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold block mb-1">Status</span>
                      <select
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="w-full border border-slate-200 p-1.5 rounded-md bg-white focus:outline-none text-slate-600"
                      >
                        <option value="all">All Statuses</option>
                        <option value="open">Open</option>
                        <option value="assigned">Assigned</option>
                        <option value="resolved">Resolved</option>
                        <option value="closed">Closed</option>
                      </select>
                    </div>
                    <div>
                      <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold block mb-1">Category</span>
                      <select
                        value={categoryFilter}
                        onChange={(e) => setCategoryFilter(e.target.value)}
                        className="w-full border border-slate-200 p-1.5 rounded-md bg-white focus:outline-none text-slate-600"
                      >
                        <option value="all">All Category</option>
                        <option value="Technical">Technical</option>
                        <option value="Billing">Billing</option>
                        <option value="Account">Account</option>
                        <option value="Feature Request">Feature Req</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Ticket cards list */}
                <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
                  {filteredTickets.length === 0 ? (
                    <div className="text-center p-8 bg-white border border-slate-100 rounded-xl">
                      <p className="text-slate-400 text-xs">No matching tickets found.</p>
                    </div>
                  ) : (
                    filteredTickets.map((t) => (
                      <div
                        key={t.id}
                        onClick={() => setSelectedTicketId(t.id)}
                        className={`p-4 bg-white rounded-xl border transition-all cursor-pointer text-left relative overflow-hidden ${
                          selectedTicketId === t.id
                            ? "border-indigo-600 shadow-md ring-1 ring-indigo-500/10"
                            : "border-slate-200/60 hover:border-slate-300"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono uppercase font-bold text-slate-400">ID: {t.id}</span>
                          <span className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-full ${
                            t.status === "open" ? "bg-amber-100 text-amber-800" :
                            t.status === "assigned" ? "bg-blue-100 text-blue-800" :
                            t.status === "resolved" ? "bg-emerald-100 text-emerald-800" :
                            "bg-slate-100 text-slate-800"
                          }`}>
                            {t.status}
                          </span>
                        </div>

                        <h4 className="font-semibold text-slate-900 text-sm mt-2 line-clamp-1">{t.title}</h4>
                        <p className="text-xs text-slate-500 mt-1 line-clamp-2">{t.description}</p>

                        <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100/80 text-[10px] text-slate-400 font-mono">
                          <span>{t.category} • {t.priority}</span>
                          <span className="text-[9px]">{new Date(t.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Detail Conversational Drawer Panel */}
              <div className="lg:col-span-8">
                {ticketDetails ? (
                  <div className="bg-white rounded-2xl border border-slate-200/60 shadow-md overflow-hidden text-left flex flex-col justify-between min-h-[550px]">
                    {/* Drawer Header */}
                    <div className="p-5 border-b border-slate-200/80 bg-slate-50/50">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-2">
                          <span className="text-xs bg-indigo-50 text-indigo-700 font-mono px-2 py-0.5 rounded">REF: {ticketDetails.id}</span>
                          <span className="text-xs text-slate-500 font-mono">Created on {new Date(ticketDetails.createdAt).toLocaleString()}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleExportReport(ticketDetails.id)}
                            className="text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 px-3.5 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1.5 shadow-sm"
                          >
                            <FileText className="w-3.5 h-3.5 text-slate-500" />
                            <span>Export PDF Report</span>
                          </button>
                          <button
                            onClick={() => handleDeleteTicket(ticketDetails.id)}
                            className="text-slate-400 hover:text-rose-500 p-1.5 rounded transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <h3 className="font-display font-bold text-lg text-slate-900 mt-3">{ticketDetails.title}</h3>
                      
                      <div className="mt-4 flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-mono bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full">Category: {ticketDetails.category}</span>
                        <span className="font-mono bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full">Urgency: {ticketDetails.priority}</span>
                        <span className="font-mono bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full">Routed: {ticketDetails.department}</span>
                        {ticketDetails.assignedStaffName && (
                          <span className="font-mono bg-teal-50 text-teal-700 px-2.5 py-0.5 rounded-full">Assigned: {ticketDetails.assignedStaffName}</span>
                        )}
                      </div>
                    </div>

                    {/* Timeline Progress */}
                    <div className="px-5 py-3 border-b border-slate-100 bg-indigo-50/20 flex items-center justify-between text-xs font-mono text-slate-500">
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${ticketDetails.status === 'open' ? 'bg-amber-400' : 'bg-slate-300'}`}></span>
                        <span className={ticketDetails.status === 'open' ? 'text-slate-800 font-semibold' : ''}>1. Intake Open</span>
                      </div>
                      <div className="h-0.5 bg-slate-200 w-8"></div>
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${ticketDetails.status === 'assigned' ? 'bg-indigo-500' : 'bg-slate-300'}`}></span>
                        <span className={ticketDetails.status === 'assigned' ? 'text-slate-800 font-semibold' : ''}>2. Assigned Desk</span>
                      </div>
                      <div className="h-0.5 bg-slate-200 w-8"></div>
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${ticketDetails.status === 'resolved' ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                        <span className={ticketDetails.status === 'resolved' ? 'text-slate-800 font-semibold' : ''}>3. Solution Response</span>
                      </div>
                      <div className="h-0.5 bg-slate-200 w-8"></div>
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${ticketDetails.status === 'closed' ? 'bg-slate-700' : 'bg-slate-300'}`}></span>
                        <span className={ticketDetails.status === 'closed' ? 'text-slate-800 font-semibold' : ''}>4. Resolved & Rating</span>
                      </div>
                    </div>

                    {/* Chat Conversation Logs list */}
                    <div className="p-5 flex-1 max-h-[380px] overflow-y-auto space-y-4">
                      {/* Original description box */}
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/50">
                        <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block mb-1">Original Issue details</span>
                        <p className="text-sm text-slate-700 whitespace-pre-wrap">{ticketDetails.description}</p>
                        {ticketDetails.screenshot && (
                          <div className="mt-4 border border-slate-200 rounded-lg overflow-hidden max-w-sm">
                            <span className="bg-slate-200 text-slate-600 text-[10px] font-mono px-2 py-0.5 block">Attached Attachment</span>
                            <img src={ticketDetails.screenshot} alt="Screenshot attachment" className="w-full object-cover max-h-48" />
                          </div>
                        )}
                      </div>

                      {/* Comments Loop */}
                      {comments.map((c) => (
                        <div
                          key={c.id}
                          className={`flex gap-3 max-w-[85%] ${
                            c.senderId === user.id ? "ml-auto flex-row-reverse text-right" : "mr-auto text-left"
                          }`}
                        >
                          <div className={`p-4.5 rounded-2xl text-sm ${
                            c.senderId === user.id
                              ? "bg-indigo-600 text-white rounded-tr-none"
                              : c.senderRole === 'ai'
                              ? "bg-indigo-50 text-indigo-900 border border-indigo-100 rounded-tl-none"
                              : "bg-slate-100 text-slate-800 rounded-tl-none"
                          }`}>
                            <div className="flex items-center justify-between gap-3 text-[10px] opacity-80 font-semibold mb-1">
                              <span>{c.senderName} • {c.senderRole.toUpperCase()}</span>
                              <span>{new Date(c.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                            </div>
                            <p className="whitespace-pre-wrap">{c.message}</p>
                          </div>
                        </div>
                      ))}

                      {/* Resolution actions if resolved */}
                      {ticketDetails.status === "resolved" && (
                        <div className="bg-emerald-50 p-5 rounded-2xl border border-emerald-100 text-center space-y-3">
                          <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto" />
                          <h4 className="font-bold text-emerald-900">This ticket has been marked as Resolved</h4>
                          <p className="text-xs text-slate-600 max-w-md mx-auto">
                            Our support staff completed auditing your issue. Please evaluate your satisfaction below to officially close out this ticket.
                          </p>
                          <button
                            onClick={() => setShowFeedbackModal(true)}
                            className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-semibold text-xs px-5 py-2.5 rounded-lg transition cursor-pointer"
                          >
                            Submit Rating Feedback
                          </button>
                        </div>
                      )}

                      {ticketDetails.feedback && (
                        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/50">
                          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block mb-1">Rating feedback details</span>
                          <div className="flex items-center gap-1.5 mb-2">
                            {[1,2,3,4,5].map((star) => (
                              <Star
                                key={star}
                                className={`w-4 h-4 ${star <= (ticketDetails.feedback?.rating || 0) ? "text-amber-400 fill-amber-400" : "text-slate-200"}`}
                              />
                            ))}
                          </div>
                          <p className="text-xs text-slate-700 italic">"{ticketDetails.feedback.comment || "No feedback comment added."}"</p>
                        </div>
                      )}
                    </div>

                    {/* Chat Footer Box */}
                    {ticketDetails.status !== "closed" && ticketDetails.status !== "resolved" && (
                      <form onSubmit={handleSendComment} className="p-4 border-t border-slate-200/80 bg-slate-50 flex items-center gap-3">
                        <input
                          type="text"
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          placeholder="Type your reply response here..."
                          className="flex-1 bg-white border border-slate-200 text-sm p-3 rounded-xl focus:outline-none"
                        />
                        <button
                          type="submit"
                          className="p-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl transition cursor-pointer active:scale-95 shrink-0"
                        >
                          <Send className="w-4 h-4" />
                        </button>
                      </form>
                    )}
                  </div>
                ) : (
                  <div className="bg-white rounded-2xl border border-slate-200/50 shadow-sm min-h-[450px] flex flex-col items-center justify-center p-8 text-center text-slate-400">
                    <MessageSquare className="w-12 h-12 text-indigo-300 mb-3" />
                    <h3 className="font-bold text-slate-700 text-sm">Select a ticket from the list</h3>
                    <p className="text-xs max-w-xs mt-1 leading-relaxed">Choose any support ticket to view details, trace automatic AI predictions, or converse directly with our staff agents.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Rating / Feedback Modal */}
      {showFeedbackModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl p-6 max-w-md w-full text-left space-y-4">
            <h3 className="font-display font-bold text-lg text-slate-900">Rate our interaction</h3>
            <p className="text-xs text-slate-500">How would you grade David Miller's response speed and assistance?</p>

            <div className="flex items-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  className="hover:scale-110 transition cursor-pointer"
                >
                  <Star
                    className={`w-8 h-8 ${star <= rating ? "text-amber-400 fill-amber-400" : "text-slate-200"}`}
                  />
                </button>
              ))}
            </div>

            <textarea
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              rows={3}
              placeholder="Add any helpful review text here (optional)..."
              className="w-full border border-slate-200 text-sm p-3 rounded-xl focus:outline-none"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowFeedbackModal(false)}
                className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSubmitFeedback}
                className="text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-5 py-2.5 rounded-xl cursor-pointer"
              >
                Submit & Close Ticket
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
