/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

// Lazy-initialization helper for Gemini API
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY" && key.trim() !== "") {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
      console.log("Gemini SDK successfully initialized with provided API key.");
    } else {
      console.warn("WARNING: GEMINI_API_KEY is not set or using placeholder. Running in Mock AI fallback mode.");
    }
  }
  return aiClient;
}

// In-Memory Database State
let users: any[] = [
  { id: "u-1", name: "Sarah Connor", email: "admin@supportflow.ai", role: "admin", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120" },
  { id: "u-2", name: "David Miller", email: "agent@supportflow.ai", role: "agent", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=120" },
  { id: "u-3", name: "Alex Mercer", email: "customer@example.com", role: "customer", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=120" }
];

let tickets: any[] = [
  {
    id: "t-1",
    title: "Invoice #9084 shows double charge for Premium Seat",
    description: "I noticed that my credit card statement shows two identical charges of $49 for invoice #9084 on June 28. My account only has 1 active premium license seat. Please refund the secondary charge immediately as this is affecting our small business budget.",
    priority: "high",
    category: "Billing",
    department: "Billing",
    status: "open",
    customerId: "u-3",
    customerName: "Alex Mercer",
    customerEmail: "customer@example.com",
    createdAt: "2026-06-29T10:15:00Z",
    updatedAt: "2026-06-29T10:18:00Z",
    tags: ["#double-charge", "#billing-dispute", "#refund-request"],
    aiAnalysis: {
      summary: "Customer was double charged $49 for Invoice #9084 on a single premium seat subscription.",
      sentiment: "Frustrated",
      suggestedSolution: "Dear Alex,\n\nThank you for reaching out and pointing this out. I have investigated Invoice #9084 and can confirm a duplicate charge of $49 occurred due to a temporary syncing glitch with our Stripe processor.\n\nI have initiated a refund of $49.00 back to your credit card. This should reflect in your account within 3-5 business days.\n\nWe apologize for this inconvenience.\n\nBest regards,\nSupportFlow AI Billing Support Team",
      predictedPriority: "high",
      suggestedDepartment: "Billing",
      confidenceScore: 98,
      tags: ["#double-charge", "#billing-dispute", "#refund-request"],
      faqMatches: ["How do I request a refund?", "Why was I charged twice?"],
      status: "pending"
    }
  },
  {
    id: "t-2",
    title: "Critical: WebSocket connections disconnecting on /ws endpoint (Error 1006)",
    description: "Our React integration is constantly throwing WebSocket connection terminations with error code 1006 every 45 seconds in production. We are losing real-time event synchronization which causes UI failures for active agents. Is there a network load balancer timeout setting?",
    priority: "urgent",
    category: "Technical",
    department: "Engineering",
    status: "assigned",
    customerId: "u-3",
    customerName: "Alex Mercer",
    customerEmail: "customer@example.com",
    assignedStaffId: "u-2",
    assignedStaffName: "David Miller",
    createdAt: "2026-06-30T08:30:00Z",
    updatedAt: "2026-06-30T14:22:00Z",
    tags: ["#websocket", "#networking", "#timeout-1006"],
    aiAnalysis: {
      summary: "Production WebSocket server drops connections every 45 seconds with error code 1006, likely due to a proxy or load balancer keepalive timeout.",
      sentiment: "Angry",
      suggestedSolution: "Hi Alex,\n\nThis behavior is characteristic of a proxy or cloud load balancer terminating idle connections. Our Nginx/Cloudflare reverse proxies have a default 60-second read timeout.\n\nTo resolve this immediately, please ensure your client-side WebSocket client sends a ping/heartbeat frame every 30 seconds. This will keep the socket active and bypass the proxy's idle termination rule.\n\nLet us know if the issue persists after adding client-side keepalive frames.\n\nBest regards,\nEngineering Team",
      predictedPriority: "urgent",
      suggestedDepartment: "Engineering",
      confidenceScore: 95,
      tags: ["#websocket", "#networking", "#timeout-1006"],
      faqMatches: ["Why does my WebSocket disconnect?", "Network proxy timeout parameters"],
      status: "accepted"
    }
  },
  {
    id: "t-3",
    title: "How do I configure OAuth redirect URIs for custom domains?",
    description: "We are moving our SupportFlow application to a custom domain (support.ourcompany.com) and need to set up Google SSO. The settings menu doesn't show where to edit redirect URLs. Can we add multiple domains to the same clientId?",
    priority: "low",
    category: "Account",
    department: "Support Ops",
    status: "resolved",
    customerId: "u-3",
    customerName: "Alex Mercer",
    customerEmail: "customer@example.com",
    assignedStaffId: "u-2",
    assignedStaffName: "David Miller",
    createdAt: "2026-06-25T14:10:00Z",
    updatedAt: "2026-06-26T09:40:00Z",
    tags: ["#oauth", "#custom-domain", "#sso-setup"],
    feedback: {
      rating: 5,
      comment: "Super helpful and answered exactly what I needed. Keep it up!",
      createdAt: "2026-06-26T10:00:00Z"
    },
    aiAnalysis: {
      summary: "Customer wants to configure Google SSO redirect URIs for their custom domain SupportFlow installation.",
      sentiment: "Neutral",
      suggestedSolution: "Hello Alex,\n\nTo configure custom domains for Google OAuth SSO, navigate to your Settings > Security > Authentication Panel. There you will find the OAuth Credentials section.\n\nYou can input multiple Authorized Redirect URIs by separating them with commas. Be sure to also whitelist these custom domains in your Google Developer Console under 'Authorized JavaScript origins'.\n\nLet us know if you have additional questions.\n\nBest,\nSupportOps Specialist",
      predictedPriority: "low",
      suggestedDepartment: "Support Ops",
      confidenceScore: 91,
      tags: ["#oauth", "#custom-domain", "#sso-setup"],
      faqMatches: ["How do I set up SSO?", "Configuring custom domains for OAuth"],
      status: "accepted"
    }
  }
];

let comments = [
  {
    id: "c-1",
    ticketId: "t-2",
    senderId: "u-2",
    senderName: "David Miller",
    senderRole: "agent",
    message: "I am taking a look at this issue right now. Checked our internal server logs, and it seems our GCP HTTPS load balancer drops connections after 60 seconds of zero data frame transfers. I recommend implementing a client-side heartbeat ping.",
    createdAt: "2026-06-30T09:45:00Z"
  },
  {
    id: "c-2",
    ticketId: "t-2",
    senderId: "u-3",
    senderName: "Alex Mercer",
    senderRole: "customer",
    message: "Thanks David. Let me try writing a keepalive heartbeat function in our React codebase and deploy. I'll let you know if that prevents the 1006 drops.",
    createdAt: "2026-06-30T10:12:00Z"
  },
  {
    id: "c-3",
    ticketId: "t-3",
    senderId: "u-2",
    senderName: "David Miller",
    senderRole: "agent",
    message: "Hi Alex! The OAuth redirect settings have been updated to support custom domains in the latest 2.4 release. You should now see the custom domain options in Settings.",
    createdAt: "2026-06-26T09:30:00Z"
  },
  {
    id: "c-4",
    ticketId: "t-3",
    senderId: "u-3",
    senderName: "Alex Mercer",
    senderRole: "customer",
    message: "Works perfectly. Marked as resolved and left 5 stars. Thanks!",
    createdAt: "2026-06-26T09:40:00Z"
  }
];

let notifications = [
  { id: "n-1", userId: "u-1", title: "Urgent Ticket Submitted", message: "New Urgent Ticket regarding WebSocket connection failures.", read: false, ticketId: "t-2", createdAt: "2026-06-30T08:31:00Z" },
  { id: "n-2", userId: "u-3", title: "Ticket Assigned", message: "Your ticket 'Critical: WebSocket connections disconnecting' has been assigned to David Miller.", read: false, ticketId: "t-2", createdAt: "2026-06-30T09:46:00Z" },
  { id: "n-3", userId: "u-3", title: "New Comment on Ticket", message: "David Miller left a comment on your Technical support request.", read: true, ticketId: "t-2", createdAt: "2026-06-30T09:45:00Z" }
];

let activityLogs = [
  { id: "a-1", ticketId: "t-1", actorName: "Alex Mercer", action: "created support ticket", createdAt: "2026-06-29T10:15:00Z" },
  { id: "a-2", ticketId: "t-1", actorName: "AI Analyst", action: "automatically performed sentiment analysis & prioritized high", createdAt: "2026-06-29T10:15:05Z" },
  { id: "a-3", ticketId: "t-2", actorName: "Alex Mercer", action: "created support ticket", createdAt: "2026-06-30T08:30:00Z" },
  { id: "a-4", ticketId: "t-2", actorName: "Admin Connor", action: "assigned ticket to Agent David Miller", createdAt: "2026-06-30T09:40:00Z" }
];

// Helper to push notifications
function addNotification(userId: string, title: string, message: string, ticketId?: string) {
  notifications.unshift({
    id: "n-" + Math.random().toString(36).substring(2, 9),
    userId,
    title,
    message,
    read: false,
    ticketId,
    createdAt: new Date().toISOString()
  });
}

// Helper to add activity log
function logActivity(ticketId: string, actorName: string, action: string) {
  activityLogs.unshift({
    id: "act-" + Math.random().toString(36).substring(2, 9),
    ticketId,
    actorName,
    action,
    createdAt: new Date().toISOString()
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // --- API ROUTES ---

  // Auth: Login
  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    // Simple mock auth matching based on role or seeded emails
    const user = users.find(u => u.email === email);
    if (user) {
      return res.json({ success: true, user });
    }
    // Dynamic mock user creations for login testing if they want
    if (email && email.includes("@")) {
      const isAgent = email.includes("agent");
      const isAdmin = email.includes("admin");
      const role = isAdmin ? "admin" : (isAgent ? "agent" : "customer");
      const newUser = {
        id: "u-" + Math.random().toString(36).substring(2, 9),
        name: email.split("@")[0].toUpperCase(),
        email,
        role,
        avatar: `https://images.unsplash.com/photo-${role === 'admin' ? '1494790108377-be9c29b29330' : '1507003211169-0a1dd7228f2d'}?auto=format&fit=crop&q=80&w=120`
      };
      users.push(newUser);
      return res.json({ success: true, user: newUser });
    }
    return res.status(401).json({ success: false, error: "Invalid credentials." });
  });

  // Auth: Register
  app.post("/api/auth/register", (req, res) => {
    const { name, email } = req.body;
    if (users.some(u => u.email === email)) {
      return res.status(400).json({ success: false, error: "Email already registered." });
    }
    const newUser = {
      id: "u-" + Math.random().toString(36).substring(2, 9),
      name,
      email,
      role: "customer" as const,
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=120"
    };
    users.push(newUser);
    return res.json({ success: true, user: newUser });
  });

  // Get Users List
  app.get("/api/users", (req, res) => {
    res.json(users);
  });

  // Update User Profile
  app.put("/api/users/:id", (req, res) => {
    const { id } = req.params;
    const { name, email, role } = req.body;
    const userIdx = users.findIndex(u => u.id === id);
    if (userIdx !== -1) {
      users[userIdx] = { ...users[userIdx], name, email, role };
      return res.json({ success: true, user: users[userIdx] });
    }
    res.status(404).json({ success: false, error: "User not found" });
  });

  // Delete User (Admin action)
  app.delete("/api/users/:id", (req, res) => {
    const { id } = req.params;
    users = users.filter(u => u.id !== id);
    res.json({ success: true });
  });

  // Fetch Tickets
  app.get("/api/tickets", (req, res) => {
    const { customerId, role } = req.query;
    let filtered = [...tickets];
    if (role === "customer" && customerId) {
      filtered = tickets.filter(t => t.customerId === customerId);
    }
    res.json(filtered);
  });

  // Fetch Single Ticket with its logs and comments
  app.get("/api/tickets/:id", (req, res) => {
    const { id } = req.params;
    const ticket = tickets.find(t => t.id === id);
    if (!ticket) {
      return res.status(404).json({ error: "Ticket not found" });
    }
    const ticketComments = comments.filter(c => c.ticketId === id);
    const ticketLogs = activityLogs.filter(l => l.ticketId === id);
    res.json({ ticket, comments: ticketComments, logs: ticketLogs });
  });

  // Create Ticket with Automatic Real-Time AI Processing
  app.post("/api/tickets", async (req, res) => {
    const { title, description, priority, category, customerId, customerName, customerEmail, screenshot } = req.body;

    const ticketId = "t-" + Math.random().toString(36).substring(2, 9);
    const date = new Date().toISOString();

    const newTicket: any = {
      id: ticketId,
      title,
      description,
      priority: priority || "medium",
      category: category || "General",
      department: "Support Ops", // Initial triage
      status: "open" as const,
      customerId,
      customerName,
      customerEmail,
      screenshot,
      createdAt: date,
      updatedAt: date,
      tags: [] as string[]
    };

    tickets.unshift(newTicket);
    logActivity(ticketId, customerName, "created support ticket");

    // Push Notification to Admin/Agents
    addNotification("u-1", "New Ticket Created", `Customer ${customerName} submitted a support ticket: "${title}"`, ticketId);

    // Call AI to immediately analyze the ticket in the background or synchronous response
    let aiAnalysis: any = null;
    const ai = getGeminiClient();

    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: `Please analyze the following customer support ticket and output a structured JSON response.

Ticket Title: ${title}
Ticket Description: ${description}
Category: ${newTicket.category}
Original Priority: ${newTicket.priority}

Please perform:
1. Issue Summary: A clear, concise summary of the issue (1-2 sentences).
2. Sentiment Detection: Classify customer sentiment into exactly one of: 'Positive', 'Neutral', 'Negative', 'Frustrated', 'Angry'.
3. Suggested Solution & Smart Reply: Generate a professional, empathetic, and constructive response draft that can be sent to the customer immediately. Be concise, polite, and actionable. Start with a warm greeting and sign off professionally.
4. Predicted Priority: Classify the urgency into exactly one of: 'low', 'medium', 'high', 'urgent'.
5. Suggested Department: Choose the best department from: 'Billing', 'Engineering', 'Support Ops', 'Product'.
6. Auto Tags: Identify 2-4 tags describing the ticket (e.g., "#password-reset", "#billing-error").
7. Confidence Score: A percentage number from 0 to 100 on how confident you are in this analysis.
8. FAQ Match: Suggest 1-2 generic FAQ questions that match this issue.`,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                summary: { type: Type.STRING },
                sentiment: { type: Type.STRING },
                suggestedSolution: { type: Type.STRING },
                predictedPriority: { type: Type.STRING },
                suggestedDepartment: { type: Type.STRING },
                tags: { type: Type.ARRAY, items: { type: Type.STRING } },
                confidenceScore: { type: Type.NUMBER },
                faqMatches: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["summary", "sentiment", "suggestedSolution", "predictedPriority", "suggestedDepartment", "tags", "confidenceScore", "faqMatches"]
            }
          }
        });

        const textResult = response.text;
        if (textResult) {
          const rawParsed = JSON.parse(textResult.trim());
          aiAnalysis = {
            summary: rawParsed.summary,
            sentiment: rawParsed.sentiment,
            suggestedSolution: rawParsed.suggestedSolution,
            predictedPriority: rawParsed.predictedPriority,
            suggestedDepartment: rawParsed.suggestedDepartment,
            confidenceScore: rawParsed.confidenceScore || 90,
            tags: rawParsed.tags || [],
            faqMatches: rawParsed.faqMatches || [],
            status: "pending"
          };
          
          // Apply some automatic AI categorization
          newTicket.tags = aiAnalysis.tags;
          newTicket.priority = aiAnalysis.predictedPriority;
          newTicket.department = aiAnalysis.suggestedDepartment;
          newTicket.aiAnalysis = aiAnalysis;

          logActivity(ticketId, "AI Engine", "automatically analyzed ticket sentiment & predicted priority");
        }
      } catch (err) {
        console.error("Gemini API processing failed, using mock AI fallback.", err);
      }
    }

    // Fallback Mock AI if Gemini client not available or fails
    if (!newTicket.aiAnalysis) {
      const descLower = description.toLowerCase();
      let sentiment = "Neutral";
      let predictedPriority = priority || "medium";
      let tags = ["#support"];
      let suggestedSolution = "Thank you for contacting us. We've received your ticket and our engineering team has been notified. We will update you as soon as possible.";
      let suggestedDept = "Technical Support";

      if (descLower.includes("billing") || descLower.includes("invoice") || descLower.includes("charge") || descLower.includes("refund")) {
        sentiment = "Frustrated";
        predictedPriority = "high";
        tags = ["#billing", "#invoice-query"];
        suggestedDept = "Billing";
        suggestedSolution = `Hello ${customerName},\n\nThank you for reaching out to billing support. I have flagged your inquiry regarding billing for urgent review by our financial desk. We will crosscheck our records for Invoice / Charges immediately.\n\nRest assured, if any error was made, we will process a refund back to your payment method.\n\nWarm regards,\nSupportFlow Billing Ops`;
      } else if (descLower.includes("crash") || descLower.includes("bug") || descLower.includes("error") || descLower.includes("broken") || descLower.includes("failed")) {
        sentiment = "Angry";
        predictedPriority = "high";
        tags = ["#bug-report", "#system-error"];
        suggestedDept = "Engineering";
        suggestedSolution = `Hi ${customerName},\n\nWe apologize for this technical malfunction. Our monitoring stack shows heightened rates in related system paths. I have dispatched your debug parameters to our engineering team.\n\nCould you please check if refreshing your browser session resolves this while we trace our server traces?\n\nSincerely,\nSupportFlow Technical Core`;
      }

      aiAnalysis = {
        summary: `Auto-summarized ticket regarding "${title}".`,
        sentiment,
        suggestedSolution,
        predictedPriority,
        suggestedDepartment: suggestedDept,
        confidenceScore: 88,
        tags,
        faqMatches: ["How do I file a general report?", "Standard server SLA guidelines"],
        status: "pending"
      };

      newTicket.tags = tags;
      newTicket.priority = predictedPriority as any;
      newTicket.department = suggestedDept;
      newTicket.aiAnalysis = aiAnalysis;
      logActivity(ticketId, "AI Engine (Local)", "automatically classified issue using offline analytics model");
    }

    res.json({ success: true, ticket: newTicket });
  });

  // Edit Ticket
  app.put("/api/tickets/:id", (req, res) => {
    const { id } = req.params;
    const { title, description, priority, category, status, department, assignedStaffId, assignedStaffName, tags } = req.body;
    const ticketIdx = tickets.findIndex(t => t.id === id);

    if (ticketIdx !== -1) {
      const original = tickets[ticketIdx];
      const updated = {
        ...original,
        title: title || original.title,
        description: description || original.description,
        priority: priority || original.priority,
        category: category || original.category,
        status: status || original.status,
        department: department || original.department,
        assignedStaffId: assignedStaffId !== undefined ? assignedStaffId : original.assignedStaffId,
        assignedStaffName: assignedStaffName !== undefined ? assignedStaffName : original.assignedStaffName,
        tags: tags || original.tags,
        updatedAt: new Date().toISOString()
      };

      tickets[ticketIdx] = updated;

      // Log actions depending on what changed
      if (status && status !== original.status) {
        logActivity(id, "Staff Dispatcher", `updated ticket status from ${original.status} to ${status}`);
        // Notify customer
        addNotification(original.customerId, "Ticket Status Updated", `Your ticket "${original.title}" has been updated to ${status}.`, id);
      }
      if (assignedStaffId && assignedStaffId !== original.assignedStaffId) {
        logActivity(id, "Staff Dispatcher", `assigned ticket to ${assignedStaffName}`);
        addNotification(assignedStaffId, "New Support Assignment", `You have been assigned support ticket: "${original.title}"`, id);
        addNotification(original.customerId, "Support Assigned", `Your ticket has been assigned to our support agent ${assignedStaffName}.`, id);
      }

      return res.json({ success: true, ticket: updated });
    }
    res.status(404).json({ success: false, error: "Ticket not found" });
  });

  // Delete Ticket
  app.delete("/api/tickets/:id", (req, res) => {
    const { id } = req.params;
    tickets = tickets.filter(t => t.id !== id);
    comments = comments.filter(c => c.ticketId !== id);
    activityLogs = activityLogs.filter(l => l.ticketId !== id);
    res.json({ success: true });
  });

  // Accept, Reject, or Edit AI Reply Action
  app.post("/api/tickets/:id/ai-action", (req, res) => {
    const { id } = req.params;
    const { action, editedReply } = req.body; // 'accept', 'reject', 'edit'
    const ticketIdx = tickets.findIndex(t => t.id === id);

    if (ticketIdx !== -1) {
      const ticket = tickets[ticketIdx];
      if (ticket.aiAnalysis) {
        ticket.aiAnalysis.status = action === "accept" ? "accepted" : (action === "reject" ? "rejected" : "edited");
        if (editedReply) {
          ticket.aiAnalysis.editedReply = editedReply;
        }

        const replyText = editedReply || ticket.aiAnalysis.suggestedSolution;

        // Auto-post as a support agent comment if accepted or edited
        if (action === "accept" || action === "edit") {
          const commentId = "c-" + Math.random().toString(36).substring(2, 9);
          comments.push({
            id: commentId,
            ticketId: id,
            senderId: "u-1", // Sent by admin/agent acting on AI suggestion
            senderName: "AI Assistant (Sent by Sarah)",
            senderRole: "ai",
            message: replyText,
            createdAt: new Date().toISOString()
          });

          // Change status to assigned/resolved depending on ticket
          ticket.status = "assigned";
          ticket.updatedAt = new Date().toISOString();

          logActivity(id, "Sarah Connor", `approved AI generated reply and dispatched email notification to customer`);
          addNotification(ticket.customerId, "AI Suggestion Sent", `Sarah sent a new solution update for ticket: "${ticket.title}"`, id);
        } else {
          logActivity(id, "Sarah Connor", `rejected AI generated reply suggestion`);
        }

        return res.json({ success: true, ticket });
      }
    }
    res.status(404).json({ error: "Ticket or AI suggestions not found" });
  });

  // Post Ticket Comment
  app.post("/api/tickets/:id/comments", (req, res) => {
    const { id } = req.params;
    const { senderId, senderName, senderRole, message } = req.body;

    const newComment = {
      id: "c-" + Math.random().toString(36).substring(2, 9),
      ticketId: id,
      senderId,
      senderName,
      senderRole,
      message,
      createdAt: new Date().toISOString()
    };

    comments.push(newComment);

    const ticket = tickets.find(t => t.id === id);
    if (ticket) {
      ticket.updatedAt = new Date().toISOString();
      logActivity(id, senderName, `posted a comment response`);

      // Dispatch notifications
      if (senderRole === "customer") {
        addNotification("u-1", "New Ticket Reply", `Customer ${senderName} replied on ticket "${ticket.title}"`, id);
      } else {
        addNotification(ticket.customerId, "Support Agent Response", `${senderName} replied on your ticket: "${ticket.title}"`, id);
      }
    }

    res.json({ success: true, comment: newComment });
  });

  // Submit Ticket Rating Feedback
  app.post("/api/tickets/:id/feedback", (req, res) => {
    const { id } = req.params;
    const { rating, comment } = req.body;
    const ticketIdx = tickets.findIndex(t => t.id === id);

    if (ticketIdx !== -1) {
      tickets[ticketIdx].feedback = {
        rating,
        comment,
        createdAt: new Date().toISOString()
      };
      tickets[ticketIdx].status = "closed";
      logActivity(id, tickets[ticketIdx].customerName, `rated the support interaction ${rating} Stars & closed ticket`);
      return res.json({ success: true, ticket: tickets[ticketIdx] });
    }
    res.status(404).json({ error: "Ticket not found" });
  });

  // Ticket Export Endpoint (Acts as PDF Generator)
  app.get("/api/tickets/:id/export", (req, res) => {
    const { id } = req.params;
    const ticket = tickets.find(t => t.id === id);
    if (!ticket) {
      return res.status(404).send("Ticket not found.");
    }

    const ticketComments = comments.filter(c => c.ticketId === id);
    const logs = activityLogs.filter(l => l.ticketId === id);

    const report = `========================================================================
                      SUPPORTFLOW AI - SYSTEM TICKET REPORT
========================================================================
TICKET REFERENCE ID : ${ticket.id}
TICKET TITLE        : ${ticket.title}
SUBMITTED DATE      : ${ticket.createdAt}
LAST MODIFIED       : ${ticket.updatedAt}
STATUS              : ${ticket.status.toUpperCase()}
PRIORITY            : ${ticket.priority.toUpperCase()}
CATEGORY            : ${ticket.category}
DEPARTMENT          : ${ticket.department}
AUTO-TAGS           : ${ticket.tags.join(', ')}

------------------------------------------------------------------------
CUSTOMER DETAILS
------------------------------------------------------------------------
Name                : ${ticket.customerName}
Email               : ${ticket.customerEmail}
Customer ID         : ${ticket.customerId}

------------------------------------------------------------------------
ISSUE DESCRIPTION
------------------------------------------------------------------------
${ticket.description}

------------------------------------------------------------------------
AI REVELATIONS & CRITICAL SENTIMENT LOGS
------------------------------------------------------------------------
AI Detected Sentiment : ${ticket.aiAnalysis?.sentiment || "N/A"}
Confidence Score      : ${ticket.aiAnalysis?.confidenceScore || "N/A"}%
AI Summary            : ${ticket.aiAnalysis?.summary || "N/A"}

AI Suggested Reply Draft:
${ticket.aiAnalysis?.suggestedSolution || "N/A"}

------------------------------------------------------------------------
INTERACTIVE HISTORY & COMMENTS (${ticketComments.length} entries)
------------------------------------------------------------------------
${ticketComments.map(c => `[${c.createdAt}] - ${c.senderName} (${c.senderRole.toUpperCase()})
Message: ${c.message}`).join("\n\n")}

------------------------------------------------------------------------
AUDIT TRAIL LOGS (${logs.length} entries)
------------------------------------------------------------------------
${logs.map(l => `[${l.createdAt}] - ${l.actorName}: ${l.action}`).join("\n")}

========================================================================
                      Generated dynamically by SupportFlow AI
========================================================================`;

    res.setHeader("Content-Disposition", `attachment; filename="SupportFlow-Report-${ticket.id}.txt"`);
    res.setHeader("Content-Type", "text/plain");
    res.send(report);
  });

  // Retrieve Notifications
  app.get("/api/notifications", (req, res) => {
    const { userId } = req.query;
    if (userId) {
      return res.json(notifications.filter(n => n.userId === userId));
    }
    res.json(notifications);
  });

  // Mark notifications as read
  app.post("/api/notifications/read", (req, res) => {
    const { userId } = req.body;
    notifications.forEach(n => {
      if (userId && n.userId === userId) {
        n.read = true;
      } else if (!userId) {
        n.read = true;
      }
    });
    res.json({ success: true });
  });

  // Retrieve Analytics Data
  app.get("/api/analytics", (req, res) => {
    const total = tickets.length;
    const open = tickets.filter(t => t.status === "open").length;
    const assigned = tickets.filter(t => t.status === "assigned").length;
    const resolved = tickets.filter(t => t.status === "resolved").length;
    const closed = tickets.filter(t => t.status === "closed").length;

    // Categories Breakdown
    const categoriesCount = tickets.reduce((acc: any, t) => {
      acc[t.category] = (acc[t.category] || 0) + 1;
      return acc;
    }, {});

    // Priorities Breakdown
    const prioritiesCount = tickets.reduce((acc: any, t) => {
      acc[t.priority] = (acc[t.priority] || 0) + 1;
      return acc;
    }, {});

    // Sentiments Breakdown
    const sentimentsCount = tickets.reduce((acc: any, t) => {
      const sent = t.aiAnalysis?.sentiment || "Neutral";
      acc[sent] = (acc[sent] || 0) + 1;
      return acc;
    }, {});

    // Feedbacks
    const feedbackList = tickets.filter(t => t.feedback).map(t => t.feedback);
    const avgSatisfaction = feedbackList.length > 0 
      ? parseFloat((feedbackList.reduce((sum, f) => sum + (f?.rating || 0), 0) / feedbackList.length).toFixed(1))
      : 4.8;

    res.json({
      metrics: {
        total,
        open,
        assigned,
        resolved,
        closed,
        avgSatisfaction,
        avgResponseTimeMinutes: 14 // Mocked SLA response speed
      },
      categories: Object.keys(categoriesCount).map(key => ({ name: key, value: categoriesCount[key] })),
      priorities: Object.keys(prioritiesCount).map(key => ({ name: key, value: prioritiesCount[key] })),
      sentiments: Object.keys(sentimentsCount).map(key => ({ name: key, value: sentimentsCount[key] })),
      monthlyVolume: [
        { month: "Jan", count: 24 },
        { month: "Feb", count: 32 },
        { month: "Mar", count: 45 },
        { month: "Apr", count: 39 },
        { month: "May", count: 58 },
        { month: "Jun", count: total + 62 } // Make it dynamic
      ]
    });
  });

  // Vite Middleware Setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`SupportFlow AI Full Stack Server successfully launched on http://0.0.0.0:${PORT}`);
  });
}

startServer();
