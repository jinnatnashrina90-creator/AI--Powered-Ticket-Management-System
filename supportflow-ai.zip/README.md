# SupportFlow AI - Helpdesk Ticket Automation Stack

SupportFlow AI is an enterprise-grade AI-powered support ticket routing, triage, and response generator system built with a high-performance full-stack architecture.

This project delivers a complete SaaS Landing Page, Customer Portal, Admin Triage Desk, and automated Google Gemini AI content analysis models.

---

## 🚀 Key Modules & Capabilities

1. **AI Automated Triage**: Automatically summarizes customer issues, classifies sentiment mood indexes (Angry, Frustrated, Neutral), drafts empathetic solution emails, and routes categories.
2. **Interactive Presenter Dock**: Toggle seamlessly between SaaS landing pages, customer portals, staff dashboards, and Laravel configurations.
3. **Interactive Screenshot Attachments**: Submit complaints with screenshots, converted into Base64 payloads for direct browser and system rendering.
4. **Interactive Dashboard Charts**: Monitor volumetric volume trends, sentiment splits, and categories counts using clean Recharts.
5. **PDF Report Exports**: Generate downloadable ticket reports with audit trails, comments, and AI sentiment values.

---

## 📐 Systems Architecture & Diagrams

### 1. Database ER Diagram (MySQL Schema)

```mermaid
erDiagram
    users {
        id string PK
        name string
        email string
        role string
        avatar string
    }
    tickets {
        id string PK
        title string
        description text
        priority string
        category string
        department string
        status string
        customer_id string FK
        assigned_staff_id string FK
        screenshot_path string
        tags json
    }
    ticket_comments {
        id string PK
        ticket_id string FK
        sender_id string FK
        message text
        sender_role string
    }
    ai_responses {
        id string PK
        ticket_id string FK
        summary text
        sentiment string
        suggested_solution text
        confidence_score integer
        status string
    }

    users ||--o{ tickets : "creates"
    users ||--o{ ticket_comments : "posts"
    tickets ||--o{ ticket_comments : "contains"
    tickets ||--|| ai_responses : "generates"
```

### 2. Live Sequence Diagram: Ticket Creation Flow

```mermaid
sequenceDiagram
    autonumber
    actor Customer
    participant Client as React Dashboard
    participant Server as Express/Vite Router
    participant LLM as Google Gemini API

    Customer->>Client: Submit ticket details + Screenshot
    Client->>Server: POST /api/tickets
    activate Server
    Server->>Server: Save Ticket records in Database
    Server->>LLM: Dispatch context prompt to gemini-3.5-flash
    activate LLM
    LLM-->>Server: Return Structured JSON (Sentiment, Summary, Reply Draft)
    deactivate LLM
    Server->>Server: Cache AI Response details
    Server-->>Client: Return newly triaged Ticket details
    deactivate Server
    Client-->>Customer: Display Success Toast + Route details
```

### 3. Flow Chart: Sentiment Analysis & Triage Routing

```mermaid
graph TD
    A[Customer submits complaint] --> B{Gemini API Key Configured?}
    B -- Yes --> C[Dispatch Gemini-3.5-Flash Request]
    B -- No --> D[Trigger Mock Local Rule Analyzer]
    C --> E[Extract Sentiment, Priority & recommended department]
    D --> E
    E --> F{Sentiment angry or frustrated?}
    F -- Yes --> G[Tag urgent & escalate to Senior Agent]
    F -- No --> H[Standard SLA dispatch route]
    G --> I[Create Activity Audit log & Client Notify]
    H --> I
```

---

## 🛠️ API Documentation

### 1. Authentication
* **POST** `/api/auth/login` - Simulates employee login. Returns User record.
* **POST** `/api/auth/register` - Registers new Customer profiles.

### 2. Support Tickets
* **GET** `/api/tickets` - Retrieve tickets. Filters: `customerId`, `role`.
* **POST** `/api/tickets` - Submit new ticket. Instantly triggers live Gemini AI.
* **PUT** `/api/tickets/:id` - Update priority, status, or assign agent.

### 3. Intelligent Operations
* **POST** `/api/tickets/:id/ai-action` - Approve, reject, or edit generated email draft replies.
* **POST** `/api/tickets/:id/comments` - Post manual conversational replies.
* **GET** `/api/tickets/:id/export` - Export downloadable ticket summary reports.

---

## 💾 Installation & Local Deployment Guide

### Node.js Sandbox (Interactive Live Prototype)
1. **Clone & Install**:
   ```bash
   npm install
   ```
2. **Setup Secrets**:
   Create a `.env` file in the root containing your Gemini API key:
   ```env
   GEMINI_API_KEY="your-gemini-api-key"
   ```
3. **Run Development Server**:
   ```bash
   npm run dev
   ```
4. **Build for Production**:
   ```bash
   npm run build
   npm run start
   ```

### Laravel 12 Production Stack
To run the actual PHP Laravel codebase:
1. Ensure **PHP 8.4** and **Composer** are installed.
2. Create standard Breeze authentication stack:
   ```bash
   laravel new supportflow-backend --breeze --stack=blade
   ```
3. Copy the PHP code files directly from the **Developer Center** view inside the running application:
   * `app/Services/AIService.php`
   * `app/Http/Controllers/TicketController.php`
   * `app/Models/Ticket.php`
   * `app/Jobs/ProcessTicketAI.php`
   * `database/migrations/create_tickets_table.php`
4. Setup your Laravel queue worker to process Gemini requests asynchronously:
   ```bash
   php artisan queue:work
   ```
